'use strict';

/* ══════════════════════════════════════════════════════
   Cart drawer fix — commerce.js sets window.openCartDrawer
   AFTER catalog resolves. We intercept the assignment so
   any click before that point is queued and fires when ready.
   ══════════════════════════════════════════════════════ */
(function(){
  var _open    = null;
  var _close   = null;
  var _pending = false;

  function openCartDrawer(){
    if(typeof _open === 'function'){ _open(); return; }
    _pending = true; // will fire as soon as commerce.js sets the fn
  }
  function closeCartDrawer(){
    if(typeof _close === 'function'){ _close(); return; }
    var d = document.getElementById('cart-drawer');
    if(d){ d.classList.remove('open'); d.setAttribute('aria-hidden','true'); document.body.classList.remove('modal-open'); }
  }

  Object.defineProperty(window, 'openCartDrawer', {
    get: function(){ return openCartDrawer; },
    set: function(fn){
      _open = fn;
      if(_pending){ _pending = false; setTimeout(fn, 30); }
    },
    configurable: true
  });
  Object.defineProperty(window, 'closeCartDrawer', {
    get: function(){ return closeCartDrawer; },
    set: function(fn){ _close = fn; },
    configurable: true
  });
})();

/* ══════════════════════════════════════════════════════
   Account modal
   ══════════════════════════════════════════════════════ */
function openAccountModal(){
  var m = document.getElementById('account-modal');
  if(!m) return;
  window.dispatchEvent(new Event('wavy-account-open'));
  m.classList.add('open');
  m.setAttribute('aria-hidden','false');
  document.body.classList.add('modal-open');
}
function closeAccountModal(){
  var m = document.getElementById('account-modal');
  if(!m) return;
  m.classList.remove('open');
  m.setAttribute('aria-hidden','true');
  if(!document.getElementById('cart-drawer')?.classList.contains('open'))
    document.body.classList.remove('modal-open');
}
function setAuthMode(mode){
  var isReg = mode === 'register';
  var h2    = document.querySelector('.account-card h2');
  var intro = document.querySelector('.auth-intro');
  if(h2)    h2.textContent    = isReg ? 'Create your account.' : 'Welcome back.';
  if(intro) intro.textContent = isReg
    ? 'Create an account to submit hosting requests.'
    : 'Sign in to your account, or register to submit a hosting request.';
  document.getElementById('login-form')    ?.classList.toggle('is-hidden',  isReg);
  document.getElementById('register-form') ?.classList.toggle('is-hidden', !isReg);
  document.getElementById('login-tab')    ?.classList.toggle('active', !isReg);
  document.getElementById('register-tab') ?.classList.toggle('active',  isReg);
  document.getElementById('login-tab')    ?.setAttribute('aria-selected', String(!isReg));
  document.getElementById('register-tab') ?.setAttribute('aria-selected', String(isReg));
}
function togglePassword(button){
  var input = button.parentElement.querySelector('input');
  if(!input) return;
  input.type = input.type === 'password' ? 'text' : 'password';
  button.textContent = input.type === 'password' ? 'Show' : 'Hide';
}
function toggleMode(){
  document.documentElement.classList.toggle('tw-light');
  localStorage.setItem('wavy-theme', document.documentElement.classList.contains('tw-light') ? 'light' : 'dark');
}

window.openAccountModal  = openAccountModal;
window.closeAccountModal = closeAccountModal;
window.setAuthMode       = setAuthMode;
window.togglePassword    = togglePassword;
window.toggleMode        = toggleMode;

// Click outside modal to close
document.getElementById('account-modal')?.addEventListener('click', function(e){
  if(e.target === this) closeAccountModal();
});

/* ══════════════════════════════════════════════════════
   Video modal
   ══════════════════════════════════════════════════════ */
function openVideo(){
  var m = document.getElementById('video-container-bg');
  if(!m) return;
  m.classList.add('open');
  m.setAttribute('aria-hidden','false');
  document.body.classList.add('modal-open');
}
function closeVideo(){
  var m = document.getElementById('video-container-bg');
  if(!m) return;
  m.classList.remove('open');
  m.setAttribute('aria-hidden','true');
  if(!document.getElementById('account-modal')?.classList.contains('open') &&
     !document.getElementById('cart-drawer')?.classList.contains('open'))
    document.body.classList.remove('modal-open');
}
window.openVideo  = openVideo;
window.closeVideo = closeVideo;
document.getElementById('video-container-bg')?.addEventListener('click', function(e){
  if(e.target === this) closeVideo();
});

/* ══════════════════════════════════════════════════════
   Global keyboard handler
   ══════════════════════════════════════════════════════ */
document.addEventListener('keydown', function(e){
  if(e.key === 'Escape'){ closeVideo(); closeAccountModal(); window.closeCartDrawer(); }
});

/* ══════════════════════════════════════════════════════
   FAQ accordion
   ══════════════════════════════════════════════════════ */
document.querySelectorAll('.faq-question').forEach(function(btn){
  btn.addEventListener('click', function(){
    var item = btn.parentElement;
    document.querySelectorAll('.faq-item.open').forEach(function(o){ if(o !== item) o.classList.remove('open'); });
    item.classList.toggle('open');
  });
});

/* ══════════════════════════════════════════════════════
   Sticky nav scroll shadow
   ══════════════════════════════════════════════════════ */
var header = document.getElementById('site-header');
if(header){
  window.addEventListener('scroll', function(){
    header.classList.toggle('scrolled', window.scrollY > 40);
  }, { passive: true });
}

/* ══════════════════════════════════════════════════════
   Cart badge: hide when 0, pop when count increases
   ══════════════════════════════════════════════════════ */
(function(){
  function updateBadge(badge){
    var n = parseInt(badge.textContent, 10) || 0;
    badge.style.display = n === 0 ? 'none' : '';
  }
  // Watch for text changes on all .cart-badge elements
  var observer = new MutationObserver(function(mutations){
    mutations.forEach(function(m){
      if(m.target.classList && m.target.classList.contains('cart-badge')){
        var badge = m.target;
        updateBadge(badge);
        // Pop animation
        badge.classList.remove('pop');
        void badge.offsetWidth; // force reflow
        badge.classList.add('pop');
      }
    });
  });
  function watchBadges(){
    document.querySelectorAll('.cart-badge').forEach(function(badge){
      updateBadge(badge);
      observer.observe(badge, { childList: true, characterData: true, subtree: true });
    });
  }
  // Watch now and after DOM is ready
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', watchBadges);
  } else {
    watchBadges();
  }
})();

/* ══════════════════════════════════════════════════════
   Open account modal from URL param
   ══════════════════════════════════════════════════════ */
if(new URLSearchParams(location.search).get('account') === '1'){
  openAccountModal();
  if(new URLSearchParams(location.search).get('tab') === 'register') setAuthMode('register');
}

/* ══════════════════════════════════════════════════════
   Nav: swap Sign In → user avatar when logged in
   ══════════════════════════════════════════════════════ */
function updateNavForUser(user){
  // Header actions area
  var ha = document.querySelector('.header-actions');
  if(!ha) return;
  // Remove sign-in button and replace with user nav
  var signinBtn = ha.querySelector('button[onclick="openAccountModal()"]');
  var getStarted = ha.querySelector('.nav-signin');
  if(signinBtn) signinBtn.remove();
  if(getStarted) getStarted.remove();

  // Add: Dashboard link + avatar
  if(!document.getElementById('nav-user-area')){
    var area = document.createElement('div');
    area.id = 'nav-user-area';
    area.style.cssText = 'display:flex;align-items:center;gap:8px;';
    area.innerHTML =
      '<a href="dashboard.html" style="font-size:13px;font-weight:700;color:#0f172a;text-decoration:none;padding:6px 12px;border-radius:8px;border:1.5px solid #e2e8f0;background:#fff;display:flex;align-items:center;gap:6px;transition:all .15s;" onmouseover="this.style.borderColor=\'#0f4eef\'" onmouseout="this.style.borderColor=\'#e2e8f0\'">'
      + '<i class="bi bi-speedometer2" style="color:#0f4eef;font-size:14px;"></i> Dashboard</a>'
      + '<a href="dashboard.html" style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#0f4eef,#3b82f6);color:#fff;font-size:12px;font-weight:800;display:flex;align-items:center;justify-content:center;text-decoration:none;border:2px solid rgba(15,78,239,.2);" title="' + user.name + '">'
      + user.name.slice(0,2).toUpperCase() + '</a>';
    // Insert before cart button
    var cartBtn = ha.querySelector('.cart-icon-button');
    if(cartBtn) ha.insertBefore(area, cartBtn);
    else ha.prepend(area);
  }

  // Mobile nav: swap sign in button
  var mobileSignIn = document.querySelector('.nav-mobile-actions .button-ghost[onclick="openAccountModal()"]');
  if(mobileSignIn){
    mobileSignIn.textContent = user.name.split(' ')[0] + ' · Dashboard';
    mobileSignIn.setAttribute('onclick','');
    mobileSignIn.href = 'dashboard.html';
    mobileSignIn.tagName === 'BUTTON' && mobileSignIn.parentNode.replaceChild(Object.assign(document.createElement('a'),{href:'dashboard.html',className:mobileSignIn.className,textContent:user.name.split(' ')[0]+' · Dashboard'}), mobileSignIn);
  }
}

window.addEventListener('wavy-account-ready', function(e){
  if(e.detail && e.detail.user) updateNavForUser(e.detail.user);
});
