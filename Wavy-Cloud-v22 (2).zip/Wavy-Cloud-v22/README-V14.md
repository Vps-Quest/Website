# Wavy Cloud website update

Open `index.html` with VS Code Live Server. Minecraft processor choices live in `mincraft-hosting.html`.

- The supplied Minecraft image is bundled locally in `assets/images/minecraft-landscape.jpg`.
- France replaces Mumbai as the available location. Singapore remains coming soon.
- Intel Xeon is enabled; AMD EPYC and AMD Ryzen are coming soon.
- Choose Drift / Current / Storm adds the existing priced plan to a browser-local preview cart.
- No payment or server is provisioned. Authentication still needs a backend.
- VPS page and its plan choices have not been changed.

## Connect the demo buttons

Paste your real Discord invite link into `discordInviteUrl` in `site-config.js`.
Until a real invite is supplied, demo buttons display an honest setup notice instead of navigating to an unrelated server.
Once connected, every demo button opens that Discord invitation in a new tab.
