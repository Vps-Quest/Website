# Wavy Cloud v19 — safe HTTP 422 diagnostic patch

This patch improves error reporting. It does NOT claim to fix the underlying panel validation error, and it does not weaken validation, permissions, ownership checks or the Successful + Paid requirement.

## Install on your existing v19
1. Stop the website's CMD window with Ctrl+C.
2. Back up your current pterodactyl.js. Also keep a backup of private-data, but DO NOT replace or delete private-data.
3. Copy BOTH pterodactyl.js and panel-errors.js from this ZIP into the existing website folder that contains server.js and package.json. Replace pterodactyl.js; panel-errors.js is a new required backend module.
4. Optional: copy the included tests folder into that same project to run the updated regression suite with npm test.
5. Start START-WEBSITE.bat again, or run npm start. Sign in to Admin again after the server restarts.
6. Open Admin > Orders, refresh the list, keep the failed order Successful + Paid, and click Save status again. No new order or new API key is needed merely to get diagnostics.
7. Read the NEW Delivery error after retry. Send its text or a screenshot; do not send keys/passwords.

Example only, not a diagnosis of your actual account:
Panel API returned HTTP 422 during panel user creation. email: invalid email format.

The message now distinguishes user lookup, user creation, server creation, account update and server update. It shows supported validation field names and normalized reasons when Pterodactyl returns them. If the response has no supported field information, the failed stage is still displayed and the panel application log is needed for further diagnosis.

Raw panel response bodies, detail strings, request values, emails, passwords, API keys and debug traces are not displayed or logged by this patch. Only allowlisted field names and fixed reasons are shown.

No private-data folder or real credentials are bundled. Saved encrypted API keys, plan mappings, customers and orders are preserved when you install just these backend files.

Validation: 47 backend tests passed, including a mocked user-creation HTTP 422, stage/field identification and remote-secret redaction. Your real panel's rejection cause has not yet been observed.
