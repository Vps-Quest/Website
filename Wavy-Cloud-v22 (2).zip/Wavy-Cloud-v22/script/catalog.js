(() => {
 'use strict';
 const services=['minecraft','vps'],families=['intel','epyc','ryzen'];
 const files={intel:'Intel-Xenon-plans.html',epyc:'Amd-Epyc-plans.html',ryzen:'Amd-Ryzen-plans.html'};
 const el=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e;};
 const service=new URLSearchParams(location.search).get('service')==='vps'?'vps':'minecraft';
 function planCards(c){
  const fname=location.pathname.split('/').pop();const fam=families.find(x=>files[x]===fname);if(!fam)return;
  const f=c.families[service][fam],grid=document.querySelector('.plan-grid');if(!grid)return;
  const label=service==='vps'?'VPS':'Minecraft';
  document.title=`${f.name} ${label} Plans · Wavy Cloud`;
  const back=document.querySelector('.service-back');back.href=service==='vps'?'vps-hosting.html':'mincraft-hosting.html';back.textContent=`← Back to ${label} hosting`;
  const hero=document.querySelector('.plan-hero');hero.replaceChildren(el('span','section-kicker',`${label.toUpperCase()} / ${f.name}`),el('h1','',f.name),el('p','',f.available?`Choose your ${label} plan. Dedicated resources, NVMe storage and DDoS protection.`:`${f.name} ${label} plans are coming soon. Check back for availability.`));
  document.querySelector('.coming-page-notice')?.remove();grid.classList.remove('coming-plan-grid');grid.replaceChildren();
  if(!f.available){grid.append(el('p','coming-page-notice','Coming soon — ordering is not available for this processor family.'));return;}
  const plans=c.plans[service+'-'+fam];if(!plans.length){grid.append(el('p','', 'No plans published yet. Please check back soon.'));return;}
  for(const p of plans){
   const card=el('article','plan-card'+(p.popular?' plan-card-popular':''));if(p.popular)card.append(el('span','plan-ribbon','MOST POPULAR'));
   if(p.offer)card.append(el('span','plan-offer',p.offer));
   card.append(el('span','plan-type',p.type),el('h2','',p.name),el('p','',p.description));
   const amounts=window.WavyPricing.price(p),price=el('div','plan-price',window.WavyPricing.money(amounts.unitCents)+' ');price.append(el('small','', '/ mo'));if(amounts.discountPercent){const original=el('div','plan-original-price');original.append(el('s','',window.WavyPricing.money(amounts.baseCents)),el('span','',` · ${amounts.discountPercent}% off`));card.append(original);}card.append(price);
   const actions=el('div','plan-actions'),btn=el('button','button '+(p.popular?'button-primary':'button-ghost'),p.button+' →');btn.type='button';btn.dataset.cartPlan=p.id;actions.append(btn);
   const demo=el('button','button demo-button','Create demo server ↗');demo.type='button';demo.dataset.demoServer='';actions.append(demo);card.append(actions);
   const list=el('ul');p.specs.forEach(s=>list.append(el('li','',s)));card.append(list);grid.append(card);
  }
 }
 function processors(c){
  const page=location.pathname.split('/').pop(),svc=page==='vps-hosting.html'?'vps':'minecraft';
  if(!['vps-hosting.html','mincraft-hosting.html'].includes(page))return;
  const grid=document.querySelector('.processor-grid');
  families.forEach(fam=>{
   const old=grid.querySelector('.processor-'+fam);if(!old)return;
   const f=c.families[svc][fam],card=el(f.available?'a':'div','processor-card processor-'+fam+(f.available?'':' processor-coming-soon'));
   if(f.available)card.href=files[fam]+'?service='+svc;else card.setAttribute('aria-disabled','true');
   card.setAttribute('aria-label',`${f.name} ${f.available?'plans available':'plans coming soon'}`);
   const art=el('div','processor-art');if(f.logo){const img=el('img','processor-logo');img.src=f.logo;img.alt=f.name+' processor logo';art.append(img);}else{const svg=old.querySelector('.processor-art svg');art.append(svg?svg.cloneNode(true):el('span','section-kicker',f.name));}
   card.append(art,el('span',f.available?'processor-available-badge':'coming-soon-badge',f.available?'AVAILABLE NOW':'COMING SOON'),old.querySelector('.processor-tag').cloneNode(true),el('h3','',f.name),old.querySelector('p').cloneNode(true),el('span','processor-link',f.available?`View ${f.name} plans ↗`:`${f.name} · Coming soon`));old.replaceWith(card);
  });
  document.querySelector('.processor-intro').textContent='Choose your processor family. Availability is shown below for each hosting option.';
  document.querySelectorAll('a[href*="-plans.html"]').forEach(a=>{const u=new URL(a.href);u.searchParams.set('service',svc);a.href=u.pathname.split('/').pop()+u.search;});
 }
 window.WavyCatalogReady=(async()=>{
  let c;
  if(location.protocol==='file:'){
   c=structuredClone(window.WavyCatalogSeed);
   const helper=el('aside','offline-helper');
   helper.append(el('span','','Offline preview · Admin changes, accounts and orders run on the server. '));
   const link=el('a','','Open live website ↗');link.href='http://localhost:3000/'+(location.pathname.split('/').pop()||'index.html')+location.search;helper.append(link);document.body.append(helper);
  }else{
   try{const r=await fetch('/api/catalog',{cache:'no-store'});if(!r.ok)throw Error();c=await r.json();}
   catch(_){try{const r=await fetch('./catalog.json',{cache:'no-store'});if(!r.ok)throw Error();c=await r.json();}catch(_){c=structuredClone(window.WavyCatalogSeed);}}
  }
  if(!c)return null;
  const home=c.home||window.WavyCatalogSeed.home;
  document.querySelectorAll('.brand-name,.cart-brand > span,.auth-logo > span').forEach(node=>{const parts=home.brandName.trim().split(/\s+/),accent=parts.length>1?parts.pop():'';node.replaceChildren(document.createTextNode(parts.join(' ')+(accent?' ':'')));if(accent)node.append(el('b','',accent));});
  document.querySelectorAll('.brand-mark img,.cart-brand img,.mini-brand img,.auth-logo img').forEach(img=>img.src=home.logo||'./assets/logo/wavy-cloud-mark.png');
  document.querySelectorAll('link[rel="icon"]').forEach(link=>link.href=home.logo||'./assets/logo/wavy-cloud-mark.png');
  const selectors={solutions:'a[href="#solutions"],a[href="index.html#solutions"]',features:'a[href="#features"]',locations:'a[href="#locations"],a[href="index.html#locations"]',faq:'a[href="#faq"],a[href="index.html#faq"]'};
  for(const [key,selector]of Object.entries(selectors))document.querySelectorAll('.main-nav,.service-nav').forEach(nav=>nav.querySelectorAll(selector).forEach(a=>a.textContent=home.navLabels[key]));
  document.querySelectorAll('.brand').forEach(a=>a.setAttribute('aria-label',home.brandName+' home'));
  document.querySelectorAll('.footer-bottom>span:first-child,.service-footer>span:first-child').forEach(e=>e.textContent=e.textContent.replace('Wavy Cloud',home.brandName));
  document.title=document.title.replace('Wavy Cloud',home.brandName);
  const kicker=document.querySelector('.auth-kicker');if(kicker)kicker.textContent='YOUR '+home.brandName.toUpperCase()+' ACCOUNT';
  window.dispatchEvent(new CustomEvent('wavy-brand-ready',{detail:home}));
  window.WavyCatalog=c;
  services.forEach(svc=>{const card=document.querySelector('.'+svc+'-card');if(card){const url=c.backgrounds[svc];card.style.backgroundImage=`linear-gradient(180deg,rgba(5,17,27,.35),rgba(5,17,27,.82) 48%,rgba(5,17,27,.97)),url(${JSON.stringify(url)})`;}});
  processors(c);planCards(c);return c;
 })();
})();
