(async () => {
  'use strict';
  const $ = id => document.getElementById(id);
  const el = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  };
  let csrf = '', catalog, service = 'minecraft', family = 'intel', view = 'home', dirty = false, saving = false, orderCache = []; 
  const files = {intel:'Intel-Xenon-plans.html', epyc:'Amd-Epyc-plans.html', ryzen:'Amd-Ryzen-plans.html'};
  async function api(url, method = 'GET', body) {
    if(location.protocol==='file:')throw Error('Offline preview. Run START-WEBSITE.bat, then open http://localhost:3000/admin.html.');
    const r = await fetch(url, {
      method, headers: {'Content-Type':'application/json', 'X-CSRF-Token':csrf},
      ...(body !== undefined ? {body:JSON.stringify(body)} : {})
    });
    let b;
    try { b = await r.json(); }
    catch (_) { throw Error('Run the Node.js backend with npm start. Static hosting cannot save admin changes.'); }
    if (!r.ok) throw Error(b.error || 'Request failed.');
    return b;
  }
  function changed() {
    dirty = true;
    $('save-state').textContent = 'Unpublished changes';
    $('save-state').style.color = '#f5cf8b';
  }
  function field(parent, title, value, onchange, options = {}) {
    const {tag='input', type='text', wide=false, max=2000} = options;
    const label = el('label', wide ? 'wide' : '', title), input = el(tag);
    input.value = value;
    if (tag === 'input') input.type = type;
    input.maxLength = max;
    if (type === 'number') { input.min = 0; input.max = 1000000; input.step = '.01'; }
    input.addEventListener('input', () => {
      onchange(type === 'number' ? Number(input.value) : input.value);
      changed();
    });
    label.append(input); parent.append(label);
    return input;
  }
  function imageEditor(value, set, kind) {
    const wrapper = el('div', 'image-editor'), preview = el('img', 'image-preview');
    preview.alt = kind;
    preview.src = value || './assets/logo/wavy-cloud-mark.png';
    const inputs = el('div', 'image-inputs');
    const url = field(inputs, 'Image URL or local assets path', value.startsWith('data:') ? '' : value, v => {
      set(v); preview.src = v || './assets/logo/wavy-cloud-mark.png';
    });
    url.placeholder = value.startsWith('data:') ? 'Uploaded image saved — paste URL to replace' : 'https://… or ./assets/images/…';
    const label = el('label', '', 'Or upload a new image'), upload = el('input');
    upload.type = 'file'; upload.accept = 'image/png,image/jpeg,image/webp,image/gif';
    upload.addEventListener('change', () => {
      const file = upload.files[0];
      if (!file) return;
      if (file.size > 2*1024*1024 || !['image/png','image/jpeg','image/webp','image/gif'].includes(file.type)) {
        alert('Choose a PNG, JPG, WebP or GIF no larger than 2 MB.'); upload.value = ''; return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        set(reader.result); preview.src = reader.result;
        url.value = ''; url.placeholder = 'Uploaded image — paste URL to replace'; changed();
      };
      reader.readAsDataURL(file);
    });
    label.append(upload);
    inputs.append(label, el('span', 'image-hint', 'PNG, JPG, WebP or GIF · max 2 MB. Publish to apply.'));
    wrapper.append(preview, inputs);
    return wrapper;
  }
  function renderHome(){
    const root=$('brand-editor');root.replaceChildren();
    const name=field(root,'Website name',catalog.home.brandName,v=>catalog.home.brandName=v,{max:60});name.parentElement.className='brand-name-field';
    root.append(imageEditor(catalog.home.logo,v=>catalog.home.logo=v,'Website logo'));
    const nav=$('nav-editor');nav.replaceChildren();
    for(const [key,label]of Object.entries({solutions:'Solutions label',features:'Why Wavy Cloud label',locations:'Locations label',faq:'FAQ label'}))field(nav,label,catalog.home.navLabels[key],v=>catalog.home.navLabels[key]=v,{max:40});
  }
  function render() {
    document.querySelectorAll('[data-view]').forEach(btn=>{const active=btn.dataset.view===view&&(view!=='hosting'||btn.dataset.service===service);btn.classList.toggle('active',active);btn.setAttribute('aria-pressed',String(active));});
    for(const name of ['home','hosting','users','orders','panel'])$(name+'-panel').hidden=name!==view;
    document.querySelector('.admin-save').hidden=!['home','hosting'].includes(view);
    if(view==='home'){renderHome();return;}
    if(view==='users'){loadUsers();return;}
    if(view==='orders'){loadOrders();return;}
    if(view==='panel'){loadPanel();return;}
    $('background-editor').replaceChildren(imageEditor(catalog.backgrounds[service],v=>catalog.backgrounds[service]=v,'Home page hosting background'));
    const grid=$('families');grid.replaceChildren();
    for(const fam of ['intel','epyc','ryzen']){
      const f=catalog.families[service][fam],box=el('article','admin-family');box.append(el('h3','',f.name));
      const label=el('label','','Availability'),select=el('select');
      for(const [value,text]of [['true','Available now'],['false','Coming soon']]){const option=el('option','',text);option.value=value;select.append(option);}
      select.value=String(f.available);select.addEventListener('change',()=>{f.available=select.value==='true';changed();});label.append(select);box.append(label,imageEditor(f.logo,v=>f.logo=v,f.name+' logo'));grid.append(box);
    }
    renderPlans();
  }
  function renderPlans(){
    family=$('plan-family').value;const plans=catalog.plans[service+'-'+family];$('plan-count').textContent=plans.length+' plans';$('preview-plans').href=files[family]+'?service='+service;const grid=$('plan-editors');grid.replaceChildren();
    if(!plans.length)grid.append(el('p','empty-plans','No plans yet. Add your first plan above.'));
    plans.forEach((p,index)=>{
      const box=el('article','plan-editor'),heading=el('div','plan-editor-heading'),title=el('h3','',`${index+1} / ${p.name}`),del=el('button','button delete-plan','Delete');del.type='button';del.setAttribute('aria-label','Delete '+p.name);
      del.addEventListener('click',()=>{if(confirm(`Delete ${p.name}? Applied when you publish.`)){plans.splice(index,1);changed();renderPlans();}});heading.append(title,del);box.append(heading);
      const quick=el('div','plan-fields');field(quick,'Plan name',p.name,v=>{p.name=v;title.textContent=`${index+1} / ${v}`;},{max:100});const preview=el('p','admin-price-preview');const refreshPrice=()=>{const amount=window.WavyPricing.price(p);preview.textContent='Customer price: '+window.WavyPricing.money(amount.unitCents)+' / month'+(amount.discountPercent?' · '+amount.discountPercent+'% off':'');};field(quick,'Base monthly price · USD',p.price,v=>{p.price=v;refreshPrice();},{type:'number'});box.append(quick,preview);
      const more=el('details','plan-extra');more.append(el('summary','','More details · offer, description & specs'));
      const fields=el('div','plan-fields');field(fields,'Plan tag',p.type,v=>p.type=v,{max:100});field(fields,'Order button label',p.button,v=>p.button=v,{max:100});
      const offer=field(fields,'Red offer · percentage auto-discounts price',p.offer||'',v=>{p.offer=v;refreshPrice();},{wide:true,max:30});offer.setAttribute('aria-label','Red offer · percentage auto-discounts price');offer.placeholder='20% OFF';offer.parentElement.append(el('span','image-hint','Use 20% OFF to automatically discount the base monthly price.'));refreshPrice();
      field(fields,'Description',p.description,v=>p.description=v,{tag:'textarea',wide:true});field(fields,'Specifications · one per line',p.specs.join('\n'),v=>p.specs=v.split('\n').map(s=>s.trim()).filter(Boolean),{tag:'textarea',wide:true,max:9000});
      const label=el('label','admin-checkbox wide'),check=el('input');check.type='checkbox';check.checked=p.popular;check.addEventListener('change',()=>{p.popular=check.checked;changed();});label.append(check,document.createTextNode('Highlight as most popular'));fields.append(label);more.append(fields);box.append(more);grid.append(box);
    });
  }
  function formatDate(value){return new Date(value).toLocaleString();}
  async function loadUsers(){
    $('user-list').textContent='Loading users…';
    try{
      const data=await api('/api/admin/users');$('mail-state').className=data.mailConfigured?'':'mail-warning';$('mail-state').textContent=data.mailConfigured?'Registration and order email notifications are enabled. Delivery status is shown below.':'Email delivery is not configured. Users and notifications are saved here. Set SMTP and ADMIN_NOTIFY_EMAIL on the server to receive emails.';
      const grid=el('div','admin-user-grid');for(const u of [...data.users].reverse()){
        const card=el('article','customer-card');card.append(el('h3','',u.name),el('p','user-email',u.email),el('p','','Registered: '+formatDate(u.createdAt)),el('p','','Last login: '+formatDate(u.lastLoginAt)),el('p','',u.orderCount+' order requests'));grid.append(card);
      }
      $('user-list').replaceChildren(data.users.length?grid:el('p','empty-plans','No registered customers yet.'));
      const list=$('notification-list');list.replaceChildren();for(const n of data.notifications.slice(0,50)){
        const card=el('article','notification-card');card.append(el('h4','',n.subject),el('p','notification-meta',`${formatDate(n.createdAt)} · Email: ${n.mailStatus}`));list.append(card);
      }
      if(!data.notifications.length)list.append(el('p','','No notifications yet.'));
    }catch(e){$('user-list').textContent=e.message;}
  }
  async function loadOrders(){
    $('order-list').textContent='Loading orders…';try{const result=await api('/api/admin/orders');orderCache=result.orders;renderOrders();const info=el('p','order-meta',result.integration.message);$('order-list').prepend(info);}catch(e){$('order-list').textContent=e.message;}
  }
  function renderOrders(){
    const filter=$('order-filter').value,list=$('order-list');list.replaceChildren();
    const visible=orderCache.filter(o=>filter==='all'||o.status===filter);
    for(const o of visible){
      const card=el('article','order-card'),top=el('div','order-card-top'),info=el('div');info.append(el('h3','',o.userName),el('p','',o.userEmail),el('p','order-meta',`${o.id.slice(0,8)} · ${formatDate(o.createdAt)}`));top.append(info,el('span','order-status '+o.status,o.status));card.append(top);
      const products=el('ul','order-items');o.items.forEach(p=>products.append(el('li','',`${p.service.toUpperCase()} / ${p.family.toUpperCase()} · ${p.name} × ${p.quantity||1} · $${(p.lineTotal??p.price).toFixed(2)} / mo`)));card.append(el('p','',`Server name: ${o.serverName||'Not supplied'} · Location: ${o.location||'France'}`));if(o.delivery)card.append(el('p','',`Delivery: ${o.delivery.state} · ${o.delivery.message}`));card.append(products,el('p','',`Monthly total: $${o.total.toFixed(2)} USD · No payment collected by this website`),el('p','',`Payment method: ${{card:'Card payment',easypaisa:'Easypaisa',jazzcash:'JazzCash',upi:'UPI'}[o.paymentMethod]||'Not selected (legacy order)'} · ${o.paymentStatus||'Not processed'}`));
      const controls=el('div','order-controls'),label=el('label','','Status'),select=el('select');for(const status of ['Pending','Successful','Suspended']){const option=el('option','',status);option.value=status;select.append(option);}select.value=o.status;select.setAttribute('aria-label','Order status');label.append(select);const noteLabel=el('label','','Admin note'),note=el('input');note.type='text';note.maxLength=1000;note.value=o.note;note.placeholder='Payment checked, unpaid, suspension reason…';noteLabel.append(note);const save=el('button','button button-ghost','Save status');save.type='button';const feedback=el('p','order-feedback');feedback.setAttribute('role','status');
      const payLabel=el('label','','Payment status'),pay=el('select');for(const v of ['Not processed','Unpaid','Paid']){const op=el('option','',v);op.value=v;pay.append(op);}pay.value=o.paymentStatus||'Not processed';payLabel.append(pay);const dateLabel=el('label','','Payment date / time (your local time)'),paidAt=el('input');paidAt.type='datetime-local';if(o.paidAt){const date=new Date(o.paidAt);paidAt.value=new Date(date-date.getTimezoneOffset()*60000).toISOString().slice(0,16);}dateLabel.append(paidAt);
      save.addEventListener('click',async()=>{save.disabled=true;try{const data=await api('/api/admin/orders','PUT',{id:o.id,status:select.value,note:note.value,updatedAt:o.updatedAt,paymentStatus:pay.value,paidAt:pay.value==='Paid'&&paidAt.value?new Date(paidAt.value).toISOString():null});Object.assign(o,data.order);renderOrders();$('feedback').textContent='Order saved. Payment is manually recorded; delivery status appears on the order.';}catch(e){feedback.textContent=e.message;}finally{save.disabled=false;}});controls.append(label,payLabel,dateLabel,noteLabel,save);card.append(controls,feedback);
      if(o.history?.length){const history=el('details','plan-extra');history.append(el('summary','','Status history'));for(const h of o.history)history.append(el('p','order-meta',`${formatDate(h.at)} · ${h.from} → ${h.to}${h.note?' · '+h.note:''}`));card.append(history);}
      list.append(card);
    }
    if(!visible.length)list.append(el('p','empty-plans','No order requests in this view.'));
  }
  let panelSettings=null,mappingPlan='',bulkDraft=null,bulkSignature='';
  function panelInput(label,value,id,type='text'){const wrap=el('label','',label),input=el('input');input.id=id;input.type=type;input.value=value??'';if(type==='number'){input.min=id==='map-swap'?'-1':'0';input.step='1';}wrap.append(input);return wrap;}
  function planById(id){return Object.values(catalog.plans).flat().find(p=>p.id===id);}
  function defaultLimits(plan){const specs=(plan.specs||[]).join(' '),ram=specs.match(/(\d+(?:\.\d+)?)\s*GB\s*RAM/i),disk=specs.match(/(\d+(?:\.\d+)?)\s*GB\s*(?:NVMe|SSD|disk|storage)/i),cores=specs.match(/(\d+(?:\.\d+)?)\s*(?:processor|CPU)\s*cores/i),cpu=specs.match(/(\d+(?:\.\d+)?)\s*%\s*CPU|CPU\s*:?\s*(\d+(?:\.\d+)?)\s*%/i);return {memory:ram?Number(ram[1])*1024:0,disk:disk?Number(disk[1])*1024:0,cpu:cpu?Number(cpu[1]||cpu[2]):cores?Number(cores[1])*100:0,swap:0,io:500};}
  function renderMapping(){mappingPlan=$('panel-plan').value;const root=$('panel-mapping-fields');root.replaceChildren();const plan=planById(mappingPlan);if(!plan){root.append(el('p','','No Minecraft plans available.'));return;}const m=panelSettings.plans[mappingPlan],limits=m?.limits||defaultLimits(plan),enable=el('label','panel-map-toggle'),check=el('input');check.type='checkbox';check.id='map-enabled';check.checked=!!m;enable.append(check,document.createTextNode(' Configure automatic delivery for this plan'));root.append(enable,el('p','panel-hint',plan.specs.join(' · ')));const fields=el('div','panel-fields');for(const [label,id,value,type]of [['Egg ID','map-egg',m?.egg||0,'number'],['Docker image','map-image',m?.docker_image||'','text'],['RAM (MB)','map-memory',limits.memory,'number'],['CPU limit (%)','map-cpu',limits.cpu,'number'],['Disk (MB)','map-disk',limits.disk,'number'],['Swap (MB; -1 means unlimited)','map-swap',limits.swap??0,'number'],['I/O weight (10–1000)','map-io',limits.io??500,'number']])fields.append(panelInput(label,value,id,type));root.append(fields);const startup=panelInput('Egg startup command',m?.startup||'','map-startup');root.append(startup);const env=el('label','','Required egg environment variables (JSON)'),textarea=el('textarea');textarea.id='map-environment';textarea.rows=4;textarea.spellcheck=false;textarea.value=JSON.stringify(m?.environment||{},null,2);env.append(textarea);root.append(env);const locations=el('div','panel-fields');for(const country of ['France','Germany','Singapore','United States'])locations.append(panelInput(country+' location ID (0 = unavailable)',m?.locations?.[country]||0,'map-location-'+country.replace(/ /g,'-'),'number'));root.append(el('h4','','Panel location IDs'),locations);const features=el('div','panel-fields');for(const [key,label]of [['databases','Database slots'],['allocations','Allocation slots'],['backups','Backup slots']])features.append(panelInput(label,m?.feature_limits?.[key]??(key==='allocations'?1:0),'map-feature-'+key,'number'));root.append(el('h4','','Feature quotas'),features,el('p','panel-hint','Save panel settings above to save this mapping too. A 5 GB plan uses 5120 MB, an 8 GB plan uses 8192 MB; 100% CPU is approximately one core.'));}
  function captureMapping(){if(!mappingPlan||!$('map-enabled'))return;if(!$('map-enabled').checked){delete panelSettings.plans[mappingPlan];return;}const num=id=>{const n=Number($(id).value);if(!Number.isInteger(n))throw Error('Resource limits and IDs must be whole numbers.');return n;},locations={};for(const country of ['France','Germany','Singapore','United States']){const id=num('map-location-'+country.replace(/ /g,'-'));if(id>0)locations[country]=id;}const environment=JSON.parse($('map-environment').value);if(!environment||typeof environment!=='object'||Array.isArray(environment))throw Error('Environment must be a JSON object.');const m={egg:num('map-egg'),docker_image:$('map-image').value.trim(),startup:$('map-startup').value.trim(),environment,limits:{memory:num('map-memory'),cpu:num('map-cpu'),disk:num('map-disk'),swap:num('map-swap'),io:num('map-io')},feature_limits:{},locations};for(const key of ['databases','allocations','backups'])m.feature_limits[key]=num('map-feature-'+key);if(m.egg<1||!m.docker_image||!m.startup||m.limits.memory<1||m.limits.disk<1||m.limits.cpu<0||m.limits.swap< -1||m.limits.io<10||m.limits.io>1000||!Object.keys(locations).length||Object.values(m.feature_limits).some(v=>v<0))throw Error('Complete the plan mapping with positive Egg/location IDs, valid limits, Docker image and startup.');panelSettings.plans[mappingPlan]=m;}
  function bulkSource(){if(!panelSettings)throw Error('Reload panel settings first.');if(!mappingPlan.startsWith('minecraft-intel-'))throw Error('Select an Intel Xeon Minecraft plan below. VPS and AMD plans are not included.');if(!$('map-enabled')?.checked)throw Error('Tick automatic delivery and complete the selected working plan first.');captureMapping();return panelSettings.plans[mappingPlan];}
  function bulkFingerprint(source){return JSON.stringify({sourceId:mappingPlan,source,plans:panelSettings.plans,catalog:catalog.plans['minecraft-intel'],overwrite:$('bulk-overwrite').checked});}
  function clearBulk(){bulkDraft=null;bulkSignature='';$('bulk-apply').disabled=true;$('bulk-preview-list').replaceChildren();}
  $('bulk-preview').onclick=()=>{clearBulk();try{const source=bulkSource();bulkDraft=window.WavyPanelBulk.prepare(catalog,panelSettings.plans,mappingPlan,source,$('bulk-overwrite').checked);bulkSignature=bulkFingerprint(source);const table=el('table'),caption=el('caption','','Intel Xeon Minecraft mappings — resource limits per server');table.append(caption);const head=el('thead'),tr=el('tr');for(const title of ['Plan','RAM (MB)','CPU (%)','Disk (MB)','Action'])tr.append(el('th','',title));head.append(tr);table.append(head);const tbody=el('tbody');for(const row of bulkDraft.rows){const tr=el('tr');for(const value of [row.name,row.memory,row.cpu,row.disk,row.action])tr.append(el('td','',String(value)));tbody.append(tr);}table.append(tbody);$('bulk-preview-list').append(table);$('bulk-feedback').textContent=bulkDraft.changed+' Intel Minecraft mappings will change. Existing mappings are '+($('bulk-overwrite').checked?'included.':'preserved. Enable the checkbox if you want to update them too.');$('bulk-apply').disabled=!bulkDraft.changed;}catch(e){clearBulk();$('bulk-feedback').textContent=e.message;}};
  $('bulk-apply').onclick=()=>{try{if(!bulkDraft)throw Error('Preview the setup first.');const source=bulkSource();if(bulkFingerprint(source)!==bulkSignature){clearBulk();throw Error('Settings changed after the preview. Preview again before applying.');}const count=bulkDraft.changed;panelSettings.plans=bulkDraft.plans;clearBulk();renderMapping();$('bulk-feedback').textContent=count+' Intel Minecraft mappings applied to the draft. Click Save panel settings above to persist them. No server was created or changed.';$('panel-feedback').textContent='Unsaved bulk setup: click Save panel settings.';}catch(e){$('bulk-feedback').textContent=e.message;}};
  $('bulk-overwrite').onchange=()=>{clearBulk();$('bulk-feedback').textContent='Preview again after changing the update option.';};
  async function loadPanel(){try{clearBulk();$('bulk-feedback').textContent='Select a working Intel Minecraft plan below, then preview. Save panel settings to persist changes.';panelSettings=(await api('/api/admin/panel')).settings;$('panel-url').value=panelSettings.panelUrl;$('panel-key').value='';$('panel-enabled').checked=panelSettings.enabled;$('panel-clear-key').checked=false;$('panel-existing-users').value=JSON.stringify(panelSettings.existingUsers,null,2);$('panel-key-state').textContent=panelSettings.keyPresent?'Key saved privately ('+panelSettings.keySource+'). It will never be shown here.':'No saved Application API key.';const select=$('panel-plan');select.replaceChildren();for(const [group,plans]of Object.entries(catalog.plans)){if(!group.startsWith('minecraft-'))continue;for(const p of plans){const op=el('option','',group+' / '+p.name+' · '+p.id);op.value=p.id;select.append(op);}}if(planById(mappingPlan))select.value=mappingPlan;renderMapping();$('panel-feedback').textContent='';}catch(e){$('panel-feedback').textContent=e.message;}}
  $('panel-plan').addEventListener('change',()=>{try{captureMapping();clearBulk();renderMapping();}catch(e){$('panel-plan').value=mappingPlan;$('panel-feedback').textContent=e.message;}});
  $('panel-settings-form').addEventListener('submit',async e=>{e.preventDefault();const btn=e.submitter;btn.disabled=true;try{if(!panelSettings)throw Error('Reload panel settings first.');captureMapping();const key=$('panel-key').value.trim();if(key&& !key.startsWith('ptla_'))throw Error('Use an Application API key (ptla_). Client keys (ptlc_) cannot create users/servers.');const result=await api('/api/admin/panel','PUT',{revision:panelSettings.revision,panelUrl:$('panel-url').value.trim(),enabled:$('panel-enabled').checked,apiKey:key,clearKey:$('panel-clear-key').checked,plans:panelSettings.plans,existingUsers:JSON.parse($('panel-existing-users').value)});panelSettings=result.settings;$('panel-key').value='';await loadPanel();$('panel-feedback').textContent='Panel settings saved privately. Test the connection, then approve a paid test order.';}catch(e){$('panel-key').value='';$('panel-feedback').textContent=e instanceof SyntaxError?'Invalid JSON in environment or existing-account links.':e.message;}finally{btn.disabled=false;}});
  $('panel-test').addEventListener('click',async()=>{$('panel-test').disabled=true;$('panel-feedback').textContent='Testing read-only Application API access…';try{$('panel-feedback').textContent=(await api('/api/admin/panel/test','POST',{})).message;}catch(e){$('panel-feedback').textContent=e.message;}finally{$('panel-test').disabled=false;}});$('panel-reload').addEventListener('click',loadPanel);
  async function start() {
    try {
      const s = await api('/api/admin/session'); csrf = s.csrf;
      catalog = await api('/api/catalog');
      $('login-panel').hidden = true; $('dashboard').hidden = false; $('logout').hidden = false;
      render();
    } catch(e) {
      $('login-panel').hidden = false; $('dashboard').hidden = true;
      $('login-feedback').textContent = e.message;
    } finally { $('loading').hidden = true; }
  }
  $('admin-login-form').addEventListener('submit', async e => {
    e.preventDefault();
    const form = e.currentTarget, btn = form.querySelector('button');
    btn.disabled = true;
    try {
      await api('/api/admin/login', 'POST', {
        email:form.elements.email.value.trim(), password:form.elements.password.value,
        remember:form.elements.remember.checked
      });
      form.elements.password.value = ''; await start();
    } catch(e) { $('login-feedback').textContent = e.message; }
    finally { btn.disabled = false; }
  });
  $('logout').addEventListener('click', async () => {
    if (dirty && !confirm('Log out and discard unpublished changes?')) return;
    try { await api('/api/admin/logout','POST',{}); dirty = false; location.href = 'index.html'; }
    catch(e) { $('feedback').textContent = e.message; }
  });
  $('save').addEventListener('click', async () => {
    if (saving) return;
    saving = true; $('save').disabled = true; $('feedback').textContent = 'Publishing…';
    try {
      catalog = await api('/api/admin/catalog', 'PUT', catalog);
      dirty = false; $('save-state').textContent = 'All changes saved';
      $('save-state').style.color = '#abdcc6';
      $('feedback').textContent = 'Published successfully. Refresh the website to see your changes.';
      render();
    } catch(e) { $('feedback').textContent = e.message; }
    finally { saving = false; $('save').disabled = false; }
  });
  document.querySelectorAll('[data-view]').forEach(btn=>btn.addEventListener('click',()=>{view=btn.dataset.view;if(btn.dataset.service)service=btn.dataset.service;render();}));
  $('refresh-users').addEventListener('click',loadUsers);$('refresh-orders').addEventListener('click',loadOrders);$('order-filter').addEventListener('change',renderOrders);
  $('plan-family').addEventListener('change', renderPlans);
  $('add-plan').addEventListener('click', () => {
    const plans = catalog.plans[service + '-' + family];
    if (plans.length >= 100) { alert('Maximum 100 plans per family.'); return; }
    const random = globalThis.crypto?.randomUUID?.() || Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
    plans.push({
      id:service + '-' + family + '-' + random, name:'New plan', price:0, type:'CUSTOM',
      description:'Describe this hosting plan.', button:'Choose plan',
      specs:['4 GB RAM','2 processor cores','30 GB NVMe storage'], popular:false, offer:''
    });
    changed(); renderPlans();
    $('plan-editors').lastElementChild.querySelector('details').open=true;
    $('plan-editors').lastElementChild.scrollIntoView({behavior:'smooth',block:'center'});
  });
  $('password-form').addEventListener('submit', async e => {
    e.preventDefault(); const form = e.currentTarget;
    try {
      await api('/api/admin/password', 'POST', {
        current:form.elements.current.value, password:form.elements.password.value
      });
      form.reset(); $('password-feedback').textContent = 'Password updated. Other admin sessions were signed out.';
    } catch(e) { $('password-feedback').textContent = e.message; }
  });
  window.addEventListener('beforeunload', e => {
    if (dirty) { e.preventDefault(); e.returnValue = ''; }
  });
  await start();
})();