(async()=>{
 'use strict';
 const catalog=await window.WavyCatalogReady;if(!catalog)return;
 const $=id=>document.getElementById(id),store=window.WavyCart,pricing=window.WavyPricing,node=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e;};
 let account=null,submitting=false,completed=false;

 // Theme (optional button — only on original checkout, not current design)
 $('checkout-theme')?.addEventListener('click',()=>{document.documentElement.classList.toggle('tw-light');localStorage.setItem('wavy-theme',document.documentElement.classList.contains('tw-light')?'light':'dark');});

 const labels={card:'Card payment',easypaisa:'Easypaisa',jazzcash:'JazzCash',upi:'UPI'};

 // ── RENDER CART ───────────────────────────────────────────
 function render(){
  if(completed)return;
  const rows=store.read(catalog);
  $('checkout-empty').hidden=!!rows.length;
  $('checkout-content').hidden=!rows.length;
  $('checkout-items').replaceChildren();
  $('checkout-units').textContent=store.count(rows)+' unit'+(store.count(rows)===1?'':'s');
  let subtotal=0,total=0;
  for(const item of rows){
   const p=store.find(catalog,item.planId),amounts=pricing.price(p),[service,family]=item.planId.split('-');
   subtotal+=amounts.baseCents*item.quantity;total+=amounts.unitCents*item.quantity;

   // ── Beautiful item card ──
   const line=document.createElement('div');
   line.dataset.planId=item.planId;
   line.style.cssText='padding:14px 22px;border-bottom:1.5px solid #f1f5f9;';

   // Top row: plan name + price
   const top=document.createElement('div');
   top.style.cssText='display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:6px;';

   const nameBlock=document.createElement('div');
   const badge=document.createElement('span');
   badge.style.cssText='font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#0f4eef;background:#eff4ff;padding:2px 8px;border-radius:20px;display:inline-block;margin-bottom:5px;';
   badge.textContent=service.toUpperCase()+' · '+catalog.families[service][family].name.toUpperCase();
   const planName=document.createElement('div');
   planName.style.cssText='font-size:15px;font-weight:800;color:#0f172a;letter-spacing:-.3px;';
   planName.textContent=p.name+(item.quantity>1?' × '+item.quantity:'');
   nameBlock.append(badge,planName);

   const priceBlock=document.createElement('div');
   priceBlock.style.cssText='text-align:right;flex-shrink:0;';
   const priceMain=document.createElement('div');
   priceMain.style.cssText='font-size:16px;font-weight:900;color:#0f172a;letter-spacing:-.4px;white-space:nowrap;';
   priceMain.textContent=pricing.money(amounts.unitCents*item.quantity)+'/mo';
   priceBlock.append(priceMain);
   if(amounts.discountPercent){
    const was=document.createElement('div');
    was.style.cssText='font-size:11px;color:#94a3b8;text-decoration:line-through;white-space:nowrap;margin-top:1px;';
    was.textContent=pricing.money(amounts.baseCents*item.quantity);
    const save=document.createElement('div');
    save.style.cssText='font-size:10px;font-weight:700;color:#16a34a;white-space:nowrap;';
    save.textContent=amounts.discountPercent+'% off';
    priceBlock.append(was,save);
   }
   top.append(nameBlock,priceBlock);

   // Specs row
   const specs=document.createElement('div');
   specs.style.cssText='font-size:11.5px;color:#64748b;margin-bottom:10px;line-height:1.5;';
   specs.textContent=p.specs.slice(0,4).join(' · ');

   // Controls row
   const controls=node('div','quantity-control');
   const minus=node('button','','−'),quantity=node('output','',String(item.quantity)),plus=node('button','','+');
   minus.type=plus.type='button';
   minus.setAttribute('aria-label','Decrease quantity for '+p.name);
   plus.setAttribute('aria-label','Increase quantity for '+p.name);
   quantity.setAttribute('aria-label','Quantity for '+p.name);
   minus.disabled=item.quantity<=1;plus.disabled=store.count(rows)>=50;
   for(const [btn,delta]of[[minus,-1],[plus,1]])btn.addEventListener('click',()=>{store.update(catalog,item.planId,delta);});
   controls.setAttribute('role','group');controls.setAttribute('aria-label','Quantity controls for '+p.name);
   controls.append(minus,quantity,plus);

   const remove=node('button','checkout-remove','Remove');remove.type='button';
   remove.setAttribute('aria-label','Remove '+p.name);
   remove.addEventListener('click',()=>store.remove(catalog,item.planId));

   const actions=document.createElement('div');
   actions.style.cssText='display:flex;align-items:center;justify-content:space-between;';
   actions.append(controls,remove);

   line.append(top,specs,actions);
   $('checkout-items').append(line);
  }
  $('checkout-subtotal').textContent=pricing.money(subtotal);
  $('checkout-savings').textContent='−'+pricing.money(subtotal-total);
  $('checkout-total').textContent=pricing.money(total)+' / mo';
  $('checkout-savings-row').hidden=subtotal===total;
 }

 // ── PAYMENT METHOD ────────────────────────────────────────
 function chosen(){return document.querySelector('input[name=paymentMethod]:checked')?.value;}
 document.querySelectorAll('input[name=paymentMethod]').forEach(input=>input.addEventListener('change',()=>{
  $('payment-description').textContent=labels[input.value]+' selected. Payment is confirmed manually by the administrator. Do not send money here.';
  try{localStorage.setItem('wavy-checkout-method',input.value);}catch(_){}
 }));
 let savedMethod;try{savedMethod=localStorage.getItem('wavy-checkout-method');}catch(_){}
 if(labels[savedMethod]){const input=document.querySelector('input[value="'+savedMethod+'"]:not(:disabled)');if(input){input.checked=true;input.dispatchEvent(new Event('change'));}}

 // ── SESSION CHECK ─────────────────────────────────────────
 // Always fetch fresh from API — no race condition with account.js
 async function checkSession(){
  if(location.protocol==='file:'){
   showAccountState(false,'Offline preview — start the server to sign in.');
   return;
  }
  try{
   const r=await fetch('/api/account/session');
   if(!r.ok)throw Error();
   const b=await r.json();
   account=b;
   window.WavyAccount=b;
   showAccountState(true,b.user.name+' · '+b.user.email);
  }catch(_){
   account=null;
   showAccountState(false,'Sign in or register to submit your order.');
  }
 }

 function showAccountState(signedIn,text){
  const state=$('checkout-account-state');
  const btn=$('checkout-sign-in');
  if(signedIn){
   state.innerHTML='<i class="bi bi-check-circle-fill" style="color:#0f4eef;margin-right:6px;font-size:15px;"></i><strong>'+text+'</strong>';
   btn.hidden=true;
  }else{
   state.textContent=text;
   btn.hidden=false;
  }
 }

 // Sign-in button: open modal if available, else redirect
 $('checkout-sign-in').addEventListener('click',e=>{
  e.preventDefault();
  localStorage.setItem('wavy-checkout-intent','1');
  if(typeof window.openAccountModal==='function'){
   window.openAccountModal();
  }else{
   location.href='index.html?account=1&checkout=1';
  }
 });

 // Re-run session check when account.js fires wavy-account-ready (after login/register)
 window.addEventListener('wavy-account-ready',()=>checkSession());

 // ── FORM SUBMIT ───────────────────────────────────────────
 $('checkout-form').addEventListener('submit',async e=>{
  e.preventDefault();
  if(submitting)return;
  const rows=store.read(catalog);
  if(!rows.length){render();return;}
  if(!chosen()){$('checkout-feedback').textContent='Choose a payment method.';return;}
  if(location.protocol==='file:'){$('checkout-feedback').textContent='Offline preview — run START-WEBSITE.bat and open http://localhost:3000/checkout.html.';return;}

  submitting=true;
  $('checkout-submit').disabled=true;
  $('checkout-content').inert=true;
  $('checkout-content').setAttribute('aria-busy','true');
  $('checkout-feedback').textContent='Saving your request…';

  try{
   // Always re-check session at submit time to get fresh CSRF
   await checkSession();
   if(!account){
    localStorage.setItem('wavy-checkout-intent','1');
    if(typeof window.openAccountModal==='function'){
     window.openAccountModal();
    }else{
     location.href='index.html?account=1&checkout=1';
    }
    $('checkout-feedback').textContent='Please sign in or register to submit your order.';
    return;
   }

   let requestId=localStorage.getItem('wavy-order-request-id');
   if(!requestId){requestId=crypto.randomUUID();localStorage.setItem('wavy-order-request-id',requestId);}

   const expectedTotal=rows.reduce((sum,item)=>sum+pricing.price(store.find(catalog,item.planId)).unitCents*item.quantity,0)/100;

   const response=await fetch('/api/orders',{
    method:'POST',
    headers:{'Content-Type':'application/json','X-CSRF-Token':account.csrf},
    body:JSON.stringify({
     items:rows,
     paymentMethod:chosen(),
     requestId,
     expectedTotal,
     serverName:$('server-name').value.trim(),
     location:$('server-location').value
    })
   });
   const b=await response.json();
   if(!response.ok)throw Error(b.error||'Unable to save request.');

   // Success
   completed=true;
   store.write([]);
   localStorage.removeItem('wavy-checkout-intent');
   localStorage.removeItem('wavy-order-request-id');
   $('checkout-content').hidden=true;
   $('checkout-empty').hidden=true;
   $('checkout-success').hidden=false;
   $('checkout-reference').textContent='Reference: '+b.order.id.slice(0,8)+' · '+labels[b.order.paymentMethod]+' · '+pricing.money(Math.round(b.order.total*100))+' / mo';
   $('checkout-success').scrollIntoView({behavior:'smooth',block:'start'});

  }catch(err){
   $('checkout-feedback').textContent=err.message;
  }finally{
   submitting=false;
   $('checkout-submit').disabled=false;
   $('checkout-content').inert=false;
   $('checkout-content').removeAttribute('aria-busy');
  }
 });

 // ── INIT ─────────────────────────────────────────────────
 window.addEventListener('wavy-cart-update',render);
 window.addEventListener('storage',e=>{if(e.key===store.KEY)render();});
 render();
 await checkSession();
})();
