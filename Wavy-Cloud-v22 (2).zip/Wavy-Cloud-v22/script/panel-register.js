(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  let session = null, profile = null;

  // ── API HELPER ──────────────────────────────────────────
  async function api(url, method = 'GET', body) {
    const r = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(session ? { 'X-CSRF-Token': session.csrf } : {})
      },
      ...(body ? { body: JSON.stringify(body) } : {})
    });
    const b = await r.json();
    if (r.status === 401) {
      session = null;
      document.querySelectorAll('input[type=password]').forEach(i => i.value = '');
      $('panel-content').hidden = true;
      $('panel-guest').hidden = false;
      setBanner('Sign in to Wavy Cloud to manage your panel account.', 'warn');
    }
    if (!r.ok) throw Error(b.error || 'Request failed.');
    return b;
  }

  // ── STATUS BANNER ───────────────────────────────────────
  function setBanner(text, type = '') {
    const b = $('panel-status-banner');
    b.className = 'panel-status-banner' + (type ? ' ' + type : '');
    b.innerHTML = (type === 'success' ? '<i class="bi bi-check-circle-fill" style="font-size:16px;flex-shrink:0;"></i> '
      : type === 'warn' ? '<i class="bi bi-exclamation-circle-fill" style="font-size:16px;flex-shrink:0;"></i> '
      : type === 'error' ? '<i class="bi bi-x-circle-fill" style="font-size:16px;flex-shrink:0;"></i> '
      : '<i class="bi bi-info-circle" style="font-size:16px;flex-shrink:0;"></i> ') + text;
  }

  // ── FEEDBACK HELPERS ────────────────────────────────────
  function setFeedback(el, text, ok) {
    el.textContent = text;
    el.className = 'pr-feedback show ' + (ok ? 'ok' : 'err');
  }
  function clearFeedback(el) {
    el.className = 'pr-feedback';
    el.textContent = '';
  }

  // ── DISPLAY ─────────────────────────────────────────────
  function display() {
    if (!profile.panelSetupAllowed) {
      $('panel-content').hidden = true;
      $('panel-guest').hidden = true;
      setBanner('Your order must be approved and paid before panel setup is available. Check your orders page.', 'warn');
      return;
    }

    $('panel-content').hidden = false;
    $('panel-guest').hidden = true;

    const panel = profile.panel;
    const notConfigured = $('panel-not-configured');

    // Show not-configured warning
    if (!profile.configured) {
      notConfigured.hidden = false;
      $('panel-register-form').querySelector('.pr-submit').disabled = true;
      $('panel-link-form').querySelector('.pr-submit').disabled = true;
    } else {
      notConfigured.hidden = true;
      $('panel-register-form').querySelector('.pr-submit').disabled = false;
      $('panel-link-form').querySelector('.pr-submit').disabled = false;
    }

    // Set panel login links
    for (const link of document.querySelectorAll('.panel-login')) {
      link.href = (profile.panelUrl || '#') + '/auth/login';
    }
    if ($('panel-reset')) $('panel-reset').href = (profile.panelUrl || '#') + '/auth/password';

    // Pre-fill email
    if ($('panel-register-form').elements.email) {
      $('panel-register-form').elements.email.value = session.user.email;
    }

    if (panel) {
      // Panel already connected
      $('panel-connected').hidden = false;
      $('panel-new').hidden = true;
      $('panel-password').style.display = '';
      $('panel-username').textContent = panel.username;
      $('panel-email').textContent = panel.email;

      // Password form: show/hide fields based on managed vs external
      const managed = panel.managedByWebsite !== false;
      $('managed-username-label').style.display = managed ? '' : 'none';
      $('current-panel-label').style.display = managed ? 'none' : '';
      if ($('panel-password-form').elements.username) {
        $('panel-password-form').elements.username.value = panel.username;
        $('panel-password-form').elements.username.required = managed;
      }
      if ($('panel-password-form').elements.panelCurrentPassword) {
        $('panel-password-form').elements.panelCurrentPassword.required = !managed;
      }

      setBanner('✅ Your panel account is connected: ' + panel.username + ' · ' + panel.email, 'success');
    } else {
      // No panel yet
      $('panel-connected').hidden = true;
      $('panel-new').hidden = false;
      $('panel-password').style.display = 'none';

      setBanner(
        profile.configured
          ? 'Signed in as ' + session.user.email + '. Fill in the form below to create your Pterodactyl panel account.'
          : 'Signed in as ' + session.user.email + '. The administrator needs to connect the panel before you can register.',
        profile.configured ? '' : 'warn'
      );
    }
  }

  async function reload() {
    profile = await api('/api/account/panel-profile');
    display();
  }

  // ── FORM HANDLERS ───────────────────────────────────────
  const forms = [
    ['panel-register-form', '/api/account/panel-register', 'panel-register-feedback'],
    ['panel-link-form',     '/api/account/panel-link',     'panel-link-feedback'],
    ['panel-password-form', '/api/account/panel-account',  'panel-password-feedback'],
  ];

  for (const [formId, route, feedbackId] of forms) {
    const form = $(formId);
    if (!form) continue;
    const feedbackEl = $(feedbackId);

    form.addEventListener('submit', async e => {
      e.preventDefault();
      clearFeedback(feedbackEl);

      const button = form.querySelector('.pr-submit');
      const data = Object.fromEntries(new FormData(form));

      // Password match check
      if (data.password && data.confirmation && data.password !== data.confirmation) {
        setFeedback(feedbackEl, 'The panel passwords do not match.', false);
        return;
      }

      button.disabled = true;
      button.innerHTML = '<span class="pr-spinner"></span> Contacting panel…';

      try {
        const endpoint = formId === 'panel-password-form' && profile?.panel?.managedByWebsite === false
          ? '/api/account/panel-password'
          : route;

        const result = await api(endpoint, 'POST', data);
        setFeedback(feedbackEl, result.message, true);
        await reload();

        if (formId === 'panel-register-form' || formId === 'panel-link-form') {
          $('panel-connected').scrollIntoView({ block: 'start', behavior: 'smooth' });
        }
      } catch (err) {
        setFeedback(feedbackEl, err.message, false);
      } finally {
        form.querySelectorAll('input[type=password]').forEach(i => i.value = '');
        // Restore button
        const labels = {
          'panel-register-form': '<i class="bi bi-person-check"></i> Create Panel Account',
          'panel-link-form':     '<i class="bi bi-shield-check"></i> Verify &amp; Connect Account',
          'panel-password-form': '<i class="bi bi-lock"></i> Update Panel Password',
        };
        button.innerHTML = labels[formId] || 'Submit';
        button.disabled = !profile?.configured;
      }
    });
  }

  // ── INIT ────────────────────────────────────────────────
  (async () => {
    try {
      setBanner('Checking your account…');
      session = await api('/api/account/session');
      await reload();
    } catch (err) {
      setBanner(err.message || 'Could not load. Please sign in.', 'error');
    }
  })();
})();
