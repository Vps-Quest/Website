(async()=>{
 'use strict';
 const catalog=await window.WavyCatalogReady;if(!catalog)return;
 const store=window.WavyCart,pricing=window.WavyPricing,drawer=document.getElementById('cart-drawer');let items=store.read(catalog),returnFocus=null;
 const node=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e;};
 function render(){
  document.querySelectorAll('.cart-badge').forEach(e=>e.textContent=store.count(items));
  const content=document.getElementById('cart-content');if(!content)return;content.replaceChildren();const footer=document.getElementById('cart-footer');footer.hidden=!items.length;
  if(!items.length){const empty=node('div','cart-empty');empty.append(node('h3','','Your next world starts here.'),node('p','','Choose a hosting plan and review it here.'));const link=node('a','cart-continue','Explore hosting plans →');link.href='index.html#solutions';empty.append(link);content.append(empty);return;}
  let total=0;
  for(const item of items){const p=store.find(catalog,item.planId);if(!p)continue;const amounts=pricing.price(p),card=node('article','cart-item'),info=node('div','cart-item-info'),[service,family]=item.planId.split('-');card.dataset.planId=item.planId;total+=amounts.unitCents*item.quantity;
   info.append(node('span','cart-item-family',service.toUpperCase()+' / '+catalog.families[service][family].name.toUpperCase()),node('h3','',p.name),node('p','',p.specs.join(' · ')));
   if(amounts.discountPercent){const discount=node('p','cart-discount-line');discount.append(node('s','',pricing.money(amounts.baseCents)),document.createTextNode(' → '+pricing.money(amounts.unitCents)+' / mo · '+amounts.discountPercent+'% off'));info.append(discount);}
   const bottom=node('div','cart-item-bottom'),price=node('strong','cart-line-price',pricing.money(amounts.unitCents*item.quantity)+' / mo');bottom.append(price);
   const controls=node('div','quantity-control');controls.setAttribute('role','group');controls.setAttribute('aria-label','Quantity controls for '+service+' '+family+' '+p.name);const minus=node('button','','−'),quantity=node('output','',String(item.quantity)),plus=node('button','','+');minus.type=plus.type='button';minus.setAttribute('aria-label','Decrease quantity for '+p.name);plus.setAttribute('aria-label','Increase quantity for '+p.name);minus.disabled=item.quantity<=1;plus.disabled=store.count(items)>=50;quantity.setAttribute('aria-label','Quantity for '+p.name);
   for(const [btn,delta]of [[minus,-1],[plus,1]])btn.addEventListener('click',()=>{store.update(catalog,item.planId,delta);const selector=delta>0?'Increase':'Decrease';[...content.querySelector('[data-plan-id="'+item.planId+'"]')?.querySelectorAll('button')||[]].find(b=>b.getAttribute('aria-label')===selector+' quantity for '+p.name)?.focus();});controls.append(minus,quantity,plus);bottom.append(controls);
   const meta=node('div','cart-item-meta');meta.append(node('span','',pricing.money(amounts.unitCents)+' each / month'));const remove=node('button','cart-remove','Remove');remove.type='button';remove.setAttribute('aria-label','Remove '+p.name+' from cart');remove.addEventListener('click',()=>store.remove(catalog,item.planId));meta.append(remove);card.append(info,bottom,meta);content.append(card);
  }
  document.getElementById('cart-total').textContent=pricing.money(total)+' / mo';
 }
 function open(){if(!drawer)return;returnFocus=document.activeElement;render();drawer.classList.add('open');drawer.setAttribute('aria-hidden','false');document.body.classList.add('modal-open');drawer.querySelector('.cart-close').focus();}
 function close(){if(!drawer||!drawer.classList.contains('open'))return;drawer.classList.remove('open');drawer.setAttribute('aria-hidden','true');if(!document.getElementById('account-modal')?.classList.contains('open'))document.body.classList.remove('modal-open');returnFocus?.focus();}
 window.openCartDrawer=open;window.closeCartDrawer=close;drawer?.addEventListener('click',e=>{if(e.target===drawer)close();});
 document.querySelectorAll('[data-cart-plan]').forEach(btn=>{const id=store.canonicalId(btn.dataset.cartPlan);if(!store.find(catalog,id)){btn.disabled=true;btn.textContent='Unavailable';return;}btn.addEventListener('click',()=>{if(!store.update(catalog,id,1)){alert('Maximum 50 units per checkout.');return;}open();});});
 document.getElementById('cart-continue')?.addEventListener('click',()=>{location.href='checkout.html';});
 // After guest sign-in/registration, return to the checkout review rather than submitting silently.
 window.WavySubmitOrder=async()=>{location.href='checkout.html';};
 window.addEventListener('wavy-cart-update',()=>{items=store.read(catalog);render();});
 window.addEventListener('storage',e=>{if(e.key===store.KEY){items=store.read(catalog);render();}});
  document.addEventListener('keydown',e=>{
    if(!drawer?.classList.contains('open'))return;
    if(e.key==='Escape'){close();return;}
    if(e.key==='Tab'){
      const controls=[...drawer.querySelectorAll('button,a[href],input')].filter(e=>!e.disabled && e.getClientRects().length);
      const first=controls[0],last=controls.at(-1);
      if(e.shiftKey && document.activeElement===first){e.preventDefault();last.focus();}
      else if(!e.shiftKey && document.activeElement===last){e.preventDefault();first.focus();}
    }
  });
  // Demo links are only enabled for the owner's real Discord invitation.
  const invite=window.WavyCloudConfig?.discordInviteUrl?.trim();
  const validInvite=invite && /^https:\/\/(?:discord\.gg\/|discord\.com\/invite\/)[A-Za-z0-9-]+\/?$/.test(invite);
  document.querySelectorAll('[data-demo-server]').forEach(btn=>{
    if(validInvite){
      const a=node('a',btn.className);
      a.innerHTML=btn.innerHTML; a.href=invite;a.target='_blank';a.rel='noopener noreferrer';a.setAttribute('data-demo-server','');
      btn.replaceWith(a);
    }else{
      btn.addEventListener('click',()=>{
        let dialog=document.getElementById('demo-link-dialog');
        if(!dialog){
          dialog=node('dialog','demo-link-dialog');dialog.id='demo-link-dialog';
          dialog.append(node('span','section-kicker','DEMO SERVERS'),node('h2','','Try before you launch.'),node('p','','Demo requests will open our Discord community once its invite link has been connected. No demo server has been created yet.'));
          const done=node('button','cart-continue','Got it');done.type='button';done.addEventListener('click',()=>dialog.close());dialog.append(done);
          dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close();});document.body.append(dialog);
        }
        dialog.showModal();
      });
    }
  });
  render();
})();
