(() => {
 'use strict';
 const login=document.getElementById('login-form'),register=document.getElementById('register-form');if(!login||!register)return;
 const node=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e;};
 const summary=node('section','account-summary');summary.hidden=true;register.after(summary);
 const msg=node('p','auth-feedback');msg.setAttribute('role','status');summary.after(msg);
 let account=null,lastOrder=null;
 function guest(){
  document.getElementById('delivery-notification')?.remove();
  account=null;lastOrder=null;window.WavyAccount=null;
  summary.hidden=true;
  var tabs=document.querySelector('.auth-tabs');
  if(tabs)tabs.hidden=false;
  window.setAuthMode?.('login');
  // Restore sign-in button in nav if it was swapped
  var area=document.getElementById('nav-user-area');
  if(area)area.remove();
 }
 async function api(route,method='GET',body){if(location.protocol==='file:')throw Error('Open http://localhost:3000 to register, sign in or order.');const r=await fetch(route,{method,headers:{'Content-Type':'application/json',...(account?{'X-CSRF-Token':account.csrf}:{})},...(body?{body:JSON.stringify(body)}:{})});const b=await r.json();if(!r.ok){if(r.status===401)guest();throw Error(b.error||'Request failed.');}return b;}
 function signedIn(){
  if(!account)return;
  // Update modal state
  var authTitle=document.getElementById('auth-title');
  var authIntro=document.querySelector('.auth-intro');
  var tabs=document.querySelector('.auth-tabs');
  if(authTitle)authTitle.textContent='Your account.';
  if(authIntro)authIntro.textContent='Track your hosting requests. No payment is collected here.';
  if(tabs)tabs.hidden=true;
  login.classList.add('is-hidden');
  register.classList.add('is-hidden');
  summary.hidden=false;
  summary.replaceChildren(node('h3','',`Hi, ${account.user.name}.`),node('p','',account.user.email));
  if(lastOrder)summary.append(node('p','account-order-result',`Request ${lastOrder.id.slice(0,8)} saved as Pending. No payment was collected. You can view it in My order requests.`));
  const history=node('a','button button-ghost','My orders');history.href='orders.html';
  const dash=node('a','button button-primary','Dashboard →');dash.href='dashboard.html';
  const logout=node('button','button button-ghost','Log out');logout.type='button';logout.addEventListener('click',async()=>{try{await api('/api/account/logout','POST',{});guest();if(typeof msg!=='undefined')msg.textContent='Signed out.';}catch(e){if(typeof msg!=='undefined'){msg.classList.add('is-error');msg.textContent=e.message;}}});
  const actions=node('div','account-actions');actions.append(dash,history,logout);summary.append(actions);

  // Swap "Sign in" button in nav to user avatar + Dashboard link on ALL pages
  (function updateNav(){
    var u=account.user;
    // Remove old sign-in button
    var signinBtn=document.querySelector('.header-actions button[onclick="openAccountModal()"]');
    if(signinBtn)signinBtn.remove();
    var getStarted=document.querySelector('.header-actions .nav-signin');
    if(getStarted)getStarted.remove();
    // Add user nav if not already added
    if(!document.getElementById('nav-user-area')){
      var ha=document.querySelector('.header-actions');
      if(ha){
        var area=document.createElement('div');
        area.id='nav-user-area';
        area.style.cssText='display:flex;align-items:center;gap:8px;';
        area.innerHTML='<a href="dashboard.html" style="font-size:13px;font-weight:700;color:#0f172a;text-decoration:none;padding:5px 12px;border-radius:8px;border:1.5px solid #e2e8f0;background:#fff;display:inline-flex;align-items:center;gap:6px;"><i class="bi bi-speedometer2" style="color:#0f4eef;font-size:13px;"></i> Dashboard</a>'
          +'<a href="dashboard.html" style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#0f4eef,#3b82f6);color:#fff;font-size:11px;font-weight:800;display:flex;align-items:center;justify-content:center;text-decoration:none;border:2px solid rgba(15,78,239,.2);" title="'+u.name+'">'+u.name.slice(0,2).toUpperCase()+'</a>';
        var cartBtn=ha.querySelector('.cart-icon-button');
        if(cartBtn)ha.insertBefore(area,cartBtn);else ha.prepend(area);
      }
    }
    // Plans page user nav
    var plansNav=document.getElementById('plans-user-nav');
    var plansAv=document.getElementById('plans-user-av');
    if(plansNav)plansNav.style.display='flex';
    if(plansAv){plansAv.textContent=u.name.slice(0,2).toUpperCase();plansAv.title=u.name;}
    // Checkout account state
    var coState=document.getElementById('checkout-account-state');
    var coBtn=document.getElementById('checkout-sign-in');
    if(coState)coState.innerHTML='<i class="bi bi-check-circle-fill" style="color:#0f4eef;margin-right:6px;font-size:15px;"></i><strong>'+u.name+'</strong> <span style="color:#64748b;">· '+u.email+'</span>';
    if(coBtn)coBtn.hidden=true;
  })();
 }
 async function afterAuth(b){
  if(b.role==='admin'){location.href='admin.html';return;}
  msg.classList.remove('is-error');account={user:b.user,csrf:b.csrf};window.WavyAccount=account;signedIn();checkDelivery();msg.textContent='Signed in successfully.';window.dispatchEvent(new CustomEvent('wavy-account-ready',{detail:account}));
  if(localStorage.getItem('wavy-checkout-intent')==='1'){localStorage.removeItem('wavy-checkout-intent');await window.WavySubmitOrder?.();}
 }
 login.addEventListener('submit',async e=>{e.preventDefault();const btn=login.querySelector('[type=submit]');btn.disabled=true;msg.textContent='Signing in…';try{await afterAuth(await api('/api/auth/login','POST',{email:login.querySelector('[type=email]').value.trim(),password:login.querySelector('[autocomplete="current-password"]').value,remember:login.querySelector('[type=checkbox]').checked}));login.querySelector('[autocomplete="current-password"]').value='';}catch(e){msg.classList.add('is-error');msg.textContent=e.message;}finally{btn.disabled=false;}});
 register.addEventListener('submit',async e=>{e.preventDefault();const btn=register.querySelector('[type=submit]');btn.disabled=true;msg.textContent='Creating account…';try{await afterAuth(await api('/api/auth/register','POST',{name:register.querySelector('[autocomplete=name]').value.trim(),email:register.querySelector('[type=email]').value.trim(),password:register.querySelector('[autocomplete="new-password"]').value,terms:register.querySelector('[type=checkbox]').checked}));register.reset();}catch(e){msg.classList.add('is-error');msg.textContent=e.message;}finally{btn.disabled=false;}});
 window.addEventListener('wavy-account-open',()=>{if(account)signedIn();});
 window.addEventListener('wavy-account-expired',guest);
 window.addEventListener('wavy-order-created',e=>{lastOrder=e.detail;signedIn();msg.textContent='';});
 async function checkDelivery(){if(!account)return;const viewerId=account.user.id;try{const b=await api('/api/account/orders');if(account?.user.id!==viewerId)return;const found=b.orders.find(o=>o.status==='Successful'&&o.paymentStatus==='Paid'&&o.delivery?.state==='Delivered'&&o.delivery.servers?.length);document.getElementById('delivery-notification')?.remove();if(!found)return;const box=node('aside','delivery-notification');box.id='delivery-notification';box.setAttribute('role','status');box.append(node('strong','','Your product has been delivered.'));const link=node('a','button button-primary','Manage now →');link.href='orders.html'+('?manage='+encodeURIComponent(found.id))+'#'+found.id;box.append(link);document.body.append(box);}catch(_){}}
 setInterval(checkDelivery,15000);
 if(location.protocol!=='file:')api('/api/account/session').then(b=>{account=b;window.WavyAccount=b;signedIn();checkDelivery();window.dispatchEvent(new CustomEvent('wavy-account-ready',{detail:b}));}).catch(()=>{});
})();
