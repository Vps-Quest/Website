// Add your real Discord invitation URL here, e.g. the link copied from your server.
// Leave blank until the invitation is supplied; no unrelated server is used.
window.WavyCloudConfig = {
  discordInviteUrl: ""
};
