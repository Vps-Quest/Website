# Historical v21 installation notes

For this complete v22 release, follow INSTALL-V22.md or START-HERE.md. The v21 bulk setup is already merged.
