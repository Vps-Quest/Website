@echo off
setlocal
cd /d "%~dp0"
set "PATH=C:\Program Files\nodejs;%PATH%"
where node >nul 2>&1
if errorlevel 1 (
 echo Node.js is missing. Install it first, then reopen this file.
 pause
 exit /b 1
)
if not exist "node_modules\nodemailer\package.json" (
 echo Installing the email-support package once...
 call npm install --omit=dev
 if errorlevel 1 (
  echo Package installation failed. Check your internet connection.
  pause
  exit /b 1
 )
)
echo Keep this window open. Website: http://localhost:3000
echo Admin: http://localhost:3000/admin.html
start "" /b cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:3000"
call npm start
pause
