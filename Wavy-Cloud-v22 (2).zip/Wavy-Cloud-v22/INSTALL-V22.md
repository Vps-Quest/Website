# Wavy Cloud v22 — complete merged website

## Upgrade safely
1. Stop your current website with Ctrl+C.
2. Back up the entire current folder, especially `private-data`.
3. Extract this ZIP into a NEW folder.
4. While both servers are stopped, COPY your existing `private-data` folder into `Wavy-Cloud-v22`, beside `server.js`. Keep the original backup.
5. Preserve any custom environment variables, `.env` file or environment startup script too. If your setup uses a custom data directory, retain that configuration instead of starting with empty data.
6. Run `START-WEBSITE.bat` inside `Wavy-Cloud-v22` (Node.js 20+). It installs nodemailer once; internet is required for this first installation. Keep the window open. Do not run the old server simultaneously.
7. Open http://localhost:3000 and press Ctrl+F5. Do not open index.html directly from disk.

Website: http://localhost:3000
Admin: http://localhost:3000/admin.html
Orders: http://localhost:3000/orders.html

Migrated data retains your users, orders, saved panel connection, mappings and admin login. For a fresh installation only, the temporary administrator is admin@gmail.com / admin; change its password before public deployment.

## Updated customer flow
- Website sign-in is still required, but panel registration is NOT required to submit a request.
- Checkout submits the request and stays on a Pending confirmation. No countdown and no panel-register.html redirect.
- Administrator checks the payment outside the website, then saves BOTH Successful and Paid.
- Panel provisioning runs only after those approvals. A delivery notification appears only after a server has actually been created, not just because approval was saved.
- When the customer returns and signs into the same website account, the site displays “Your product has been delivered” with Manage now.
- Manage now opens that order in My Order Requests and its panel setup. The real configured panel login link is shown at the top.
- The customer sets their panel username/password there. The server is already assigned to the automatically created account using their website email; do not create a duplicate account in the panel.
- Later the same section supports panel password changes and server controls. Website and panel passwords remain separate.
- If provisioning fails, review the error in Admin → Orders, fix the connection/mapping and retry. Failed delivery is not presented as delivered. An existing panel-email conflict has a verified existing-account recovery option.

## Preserved features and limits
The v21 Intel Minecraft bulk setup is included. No extra patch is needed. Existing mappings remain untouched unless you explicitly opt to update them. VPS and AMD are excluded from Intel bulk setup.
No QR/payment gateway has been added in this release. Payment selection does not collect money. No automatic expiry suspension, VPS deployment or renewal billing is included.
Live status/power requires the customer's own verified Client API key; never use a shared administrator Client key.

This archive contains no private-data, live credentials or API keys. Copy your actual local private-data to retain those settings; screenshots cannot provide them. No changes to your installed HuxRegister addon are required.

## Validation
55 backend test cases passed. Desktop/mobile mocked-panel browser checks covered Pending checkout without a panel account, no countdown, approval gates, real delivery notification, Manage now navigation, panel link, password setup and clearing, and existing bulk setup.
These checks use a mock panel. Real delivery still depends on your live Application key, working Egg/environment values, mappings and node capacity; it has not been verified against your production panel here.
