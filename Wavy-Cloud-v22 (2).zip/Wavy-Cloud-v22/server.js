'use strict';
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const pricing=require('./script/pricing.js');
const ROOT=__dirname,DATA=path.resolve(process.env.DATA_DIR||path.join(ROOT,'private-data'));
fs.mkdirSync(DATA,{recursive:true});
const paths={catalog:path.join(DATA,'catalog.json'),admin:path.join(DATA,'admin.json'),users:path.join(DATA,'users.json'),orders:path.join(DATA,'orders.json'),notifications:path.join(DATA,'notifications.json')};
function persist(file,obj){const tmp=file+'.tmp';fs.writeFileSync(tmp,JSON.stringify(obj,null,2),{mode:0o600});fs.renameSync(tmp,file);}
function load(file,initial){if(!fs.existsSync(file))persist(file,initial);return JSON.parse(fs.readFileSync(file,'utf8'));}
const seed=JSON.parse(fs.readFileSync(path.join(ROOT,'catalog.json'),'utf8'));
let catalog=load(paths.catalog,seed);
// Non-destructive migration from v15: keep the owner's existing plans and images.
if(!catalog.home)catalog.home=structuredClone(seed.home);
for(const [group,list]of Object.entries(catalog.plans))for(const p of list)if(p.offer===undefined)p.offer=seed.plans[group]?.find(x=>x.id===p.id)?.offer||'';
persist(paths.catalog,catalog);
const hash=(pw,salt)=>crypto.scryptSync(pw,salt,64).toString('hex');
const equal=(a,b)=>crypto.timingSafeEqual(Buffer.from(a,'hex'),Buffer.from(b,'hex'));
const salt=crypto.randomBytes(16).toString('hex');
let credentials=load(paths.admin,{email:process.env.ADMIN_EMAIL||'admin@gmail.com',salt,hash:hash(process.env.ADMIN_PASSWORD||'admin',salt)});
let users=load(paths.users,[]),orders=load(paths.orders,[]),notifications=load(paths.notifications,[]);
const ptero=require('./pterodactyl.js')({dataDir:DATA,persist,hasBindings:()=>users.some(u=>u.panel?.id)||orders.some(o=>o.delivery?.servers?.length)}),deliveryLocks=new Set();
const saveOrders=()=>persist(paths.orders,orders),saveUsers=()=>persist(paths.users,users);
function customerOrder(o){const {history,...safe}=o;const u=users.find(u=>u.id===o.userId);if(u?.panel)safe.panelAccount={username:u.panel.username,email:u.email,setupComplete:!!u.panel.setupComplete,managedByWebsite:u.panel.managedByWebsite!==false,liveConnected:!!u.panel.clientKey};return safe;}
const sessions=new Map(),customers=new Map(),attempts=new Map(),production=process.env.NODE_ENV==='production';
if(production&&equal(hash('admin',credentials.salt),credentials.hash)){console.error('Change the temporary admin password before production.');process.exit(1);}
const str=(v,max=2000)=>typeof v==='string'&&v.length<=max;
const emailValid=v=>str(v,254)&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const emailOf=v=>typeof v==='string'?v.trim().toLowerCase():'';
function image(v){return str(v,3000000)&&(!v||/^\.\/assets\/[a-zA-Z0-9_./-]+$/.test(v)||/^https:\/\/[^\s"<>]+$/.test(v)||/^data:image\/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(v));}
function validate(c){
 if(!c||!c.backgrounds||!c.families||!c.plans||!c.home)throw Error('Invalid catalog.');
 if(!str(c.home.brandName,60)||!c.home.brandName.trim()||!image(c.home.logo))throw Error('Invalid brand name or logo.');
 for(const key of ['solutions','features','locations','faq'])if(!str(c.home.navLabels?.[key],40)||!c.home.navLabels[key].trim())throw Error('Navigation labels must contain 1–40 characters.');
 for(const svc of ['minecraft','vps']){
  if(!image(c.backgrounds[svc]))throw Error('Use a local assets path, HTTPS URL or PNG/JPG/WebP/GIF upload.');
  for(const fam of ['intel','epyc','ryzen']){
   const f=c.families[svc]?.[fam];if(!f||!str(f.name,100)||!f.name.trim()||typeof f.available!=='boolean'||!image(f.logo))throw Error('Invalid processor settings.');
   const list=c.plans[svc+'-'+fam];if(!Array.isArray(list)||list.length>100)throw Error('Maximum 100 plans per family.');
   const ids=new Set();for(const p of list){if(!str(p.id,120)||!p.id.startsWith(svc+'-'+fam+'-')||!/^[a-zA-Z0-9-]+$/.test(p.id)||ids.has(p.id)||!str(p.name,100)||!p.name.trim()||!str(p.description)||!str(p.type,100)||!str(p.button,100)||!p.button.trim()||!str(p.offer,30)||!Number.isFinite(p.price)||p.price<0||p.price>1000000||typeof p.popular!=='boolean'||!Array.isArray(p.specs)||p.specs.length>30||p.specs.some(x=>!str(x,300)))throw Error('Invalid plan fields.');const discount=String(p.offer).match(/([+-]?\d+(?:\.\d+)?)\s*%/);if(discount&&(Number(discount[1])<0||Number(discount[1])>100))throw Error('Offer percentages must be between 0 and 100.');ids.add(p.id);}
  }
 }
}
function getSession(req,map,name){const id=(req.headers.cookie||'').match(new RegExp('(?:^|;\\s*)'+name+'=([a-f0-9]+)'))?.[1],s=map.get(id);if(!s||s.expires<Date.now()){map.delete(id);return null;}return {id,...s};}
const adminSession=req=>getSession(req,sessions,'wavy_admin'),userSession=req=>getSession(req,customers,'wavy_customer');
function signIn(res,map,name,data,remember){const id=crypto.randomBytes(32).toString('hex'),csrf=crypto.randomBytes(24).toString('hex'),ttl=remember?7*86400:8*3600;map.set(id,{...data,csrf,expires:Date.now()+ttl*1000});res.setHeader('Set-Cookie',`${name}=${id}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${ttl}${production?'; Secure':''}`);return csrf;}
function throttle(req,kind){const key=kind+':'+req.socket.remoteAddress;let a=attempts.get(key);if(!a||a.until<Date.now()){a={count:0,until:Date.now()+15*60*1000};attempts.set(key,a);}a.count++;return a.count<=(kind==='register'?10:20);}
const json=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
async function body(req){let size=0,parts=[];for await(const part of req){size+=part.length;if(size>12*1024*1024)throw Error('Save request exceeds 12 MB.');parts.push(part);}return JSON.parse(Buffer.concat(parts).toString());}
function safeUser(u){return {id:u.id,name:u.name,email:u.email,createdAt:u.createdAt,lastLoginAt:u.lastLoginAt};}
let transporter=null;
const mailConfigured=!!(process.env.SMTP_HOST&&process.env.SMTP_FROM&&process.env.ADMIN_NOTIFY_EMAIL);
if(mailConfigured){const nodemailer=require('nodemailer');transporter=nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:process.env.SMTP_SECURE==='true',requireTLS:process.env.SMTP_SECURE!=='true',...(process.env.SMTP_USER?{auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS||''}}:{}),connectionTimeout:10000,socketTimeout:10000});}
function notify(kind,subject,text,userId){
 const n={id:crypto.randomUUID(),kind,subject,text,userId,createdAt:new Date().toISOString(),mailStatus:transporter?'Sending':'Not configured'};notifications.unshift(n);persist(paths.notifications,notifications);
 if(transporter)transporter.sendMail({from:process.env.SMTP_FROM,to:process.env.ADMIN_NOTIFY_EMAIL,subject,text}).then(()=>{n.mailStatus='Sent';persist(paths.notifications,notifications);}).catch(()=>{n.mailStatus='Failed';persist(paths.notifications,notifications);});
}
const server=http.createServer(async(req,res)=>{
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','same-origin');res.setHeader('X-Frame-Options','DENY');
 try{
  const route=new URL(req.url,'http://localhost').pathname;
  if(route.startsWith('/api/')){
   if(!['GET','POST','PUT'].includes(req.method))return json(res,405,{error:'Method not allowed.'});
   if(req.method!=='GET'){
    const origin=req.headers.origin,allowed=process.env.PUBLIC_ORIGIN;
    if(!origin||(allowed?origin!==allowed:new URL(origin).host!==req.headers.host))return json(res,403,{error:'Invalid request origin.'});
    if(!(req.headers['content-type']||'').startsWith('application/json'))return json(res,415,{error:'JSON required.'});
   }
   if(route==='/api/catalog'&&req.method==='GET')return json(res,200,catalog);
   if(['/api/admin/login','/api/auth/login'].includes(route)&&req.method==='POST'){
    if(!throttle(req,'login'))return json(res,429,{error:'Too many attempts. Try again in 15 minutes.'});
    const b=await body(req),email=emailOf(b.email),pw=str(b.password,256)?b.password:'';
    if(email===emailOf(credentials.email)){
     if(!equal(hash(pw,credentials.salt),credentials.hash))return json(res,401,{error:'Incorrect email or password.'});
     signIn(res,sessions,'wavy_admin',{},b.remember);return json(res,200,{ok:true,role:'admin'});
    }
    if(route==='/api/admin/login')return json(res,401,{error:'Incorrect admin email or password.'});
    const u=users.find(u=>u.email===email);const candidate=hash(pw,u?.salt||credentials.salt);
    if(!u||!equal(candidate,u.hash))return json(res,401,{error:'Incorrect email or password.'});
    u.lastLoginAt=new Date().toISOString();persist(paths.users,users);const csrf=signIn(res,customers,'wavy_customer',{userId:u.id},b.remember);return json(res,200,{ok:true,role:'customer',user:safeUser(u),csrf});
   }
   if(route==='/api/auth/register'&&req.method==='POST'){
    if(!throttle(req,'register'))return json(res,429,{error:'Too many registrations. Try again in 15 minutes.'});
    const b=await body(req),email=emailOf(b.email);
    if(!str(b.name,100)||!b.name.trim()||!emailValid(email)||!str(b.password,256)||b.password.length<8||b.terms!==true)return json(res,400,{error:'Provide a name, valid email, password with 8+ characters, and accept the terms.'});
    if(users.some(u=>u.email===email)||email===emailOf(credentials.email))return json(res,409,{error:'This email is already registered. Please sign in.'});
    const salt=crypto.randomBytes(16).toString('hex'),now=new Date().toISOString(),u={id:crypto.randomUUID(),name:b.name.trim(),email,salt,hash:hash(b.password,salt),createdAt:now,lastLoginAt:now};
    users.push(u);persist(paths.users,users);const csrf=signIn(res,customers,'wavy_customer',{userId:u.id},true);
    notify('Registration',`New registration: ${u.email}`,`Name: ${u.name}\nEmail: ${u.email}\nRegistered: ${now}`,u.id);
    return json(res,201,{ok:true,role:'customer',user:safeUser(u),csrf});
   }
   if(route.startsWith('/api/account/')||route==='/api/orders'){
    const s=userSession(req),u=s&&users.find(u=>u.id===s.userId);if(!u)return json(res,401,{error:'Please log in or register before submitting an order request.'});
    if(route==='/api/account/session'&&req.method==='GET')return json(res,200,{user:safeUser(u),csrf:s.csrf,panel:ptero.profile(u).panel});
    if(route==='/api/account/panel-profile'&&req.method==='GET')return json(res,200,{...ptero.profile(u),panelSetupAllowed:orders.some(o=>o.userId===u.id&&o.status==='Successful'&&o.paymentStatus==='Paid')});
    if(route==='/api/account/orders'&&req.method==='GET')return json(res,200,{orders:orders.filter(o=>o.userId===u.id).map(customerOrder)});
    if(route==='/api/account/server-status'&&req.method==='GET'){const q=new URL(req.url,'http://localhost').searchParams,o=orders.find(o=>o.id===q.get('orderId')&&o.userId===u.id),server=o?.delivery?.servers?.find(s=>String(s.id)===q.get('serverId'));if(!server)return json(res,404,{error:'Your server was not found.'});return json(res,200,await ptero.status(u,server));}
   if(req.headers['x-csrf-token']!==s.csrf)return json(res,403,{error:'Session security token is invalid. Sign in again.'});
    if(['/api/account/panel-register','/api/account/panel-link','/api/account/panel-password'].includes(route)&&req.method==='POST'){if(!throttle(req,'panel-account'))return json(res,429,{error:'Too many attempts. Retry in 15 minutes.'});if(!orders.some(o=>o.userId===u.id&&o.status==='Successful'&&o.paymentStatus==='Paid'))return json(res,409,{error:'Panel setup becomes available after the administrator approves and confirms payment for your order.'});const b=await body(req);if(!str(b.currentPassword,256)||!equal(hash(b.currentPassword,u.salt),u.hash))return json(res,403,{error:'Your current website password is incorrect.'});if(route.endsWith('panel-register'))return json(res,201,await ptero.registerAccount(u,b,saveUsers));if(route.endsWith('panel-link'))return json(res,200,await ptero.linkExisting(u,b.apiKey,saveUsers));return json(res,200,await ptero.clientPassword(u,b,saveUsers));}
    if(route==='/api/account/server-power'&&req.method==='POST'){if(!throttle(req,'server-power'))return json(res,429,{error:'Too many power requests. Please wait.'});const b=await body(req),o=orders.find(o=>o.id===b.orderId&&o.userId===u.id),server=o?.delivery?.servers?.find(s=>s.id===b.serverId);if(!server)return json(res,404,{error:'Your server was not found.'});if(o.status!=='Successful'||o.paymentStatus!=='Paid'||o.delivery.state!=='Delivered'||(o.delivery.expiresAt&&Date.parse(o.delivery.expiresAt)<Date.now()))return json(res,409,{error:'Only an active, successful, paid delivered order can use power controls.'});return json(res,200,await ptero.power(u,server,b.signal));}
    if(route==='/api/account/panel-credentials'&&req.method==='POST'){const b=await body(req);const o=orders.find(o=>o.id===b.orderId&&o.userId===u.id);if(!o||!o.delivery?.servers?.length)return json(res,404,{error:'No delivered server for this account.'});return json(res,200,{credentials:ptero.credentials(u),delivery:o.delivery});}
    if(route==='/api/account/panel-account'&&req.method==='POST'){if(!throttle(req,'panel-account'))return json(res,429,{error:'Too many password attempts. Retry later.'});const b=await body(req);if(!str(b.currentPassword,256)||!equal(hash(b.currentPassword,u.salt),u.hash))return json(res,403,{error:'Your current website password is incorrect.'});return json(res,200,await ptero.updateAccount(u,b,saveUsers));}
    if(route==='/api/account/server-name'&&req.method==='POST'){const b=await body(req),o=orders.find(o=>o.id===b.orderId&&o.userId===u.id),server=o?.delivery?.servers?.find(s=>s.id===b.serverId);if(!server)return json(res,404,{error:'Your server was not found.'});return json(res,200,await ptero.rename(u,o,server,b.name,saveOrders));}
    if(route==='/api/account/panel-live-key'&&req.method==='POST'){const b=await body(req);if(b.disconnect===true){if(u.panel)delete u.panel.clientKey;saveUsers();return json(res,200,{ok:true});}return json(res,200,await ptero.connectLive(u,b.apiKey,saveUsers));}
    if(route==='/api/account/logout'&&req.method==='POST'){customers.delete(s.id);res.setHeader('Set-Cookie','wavy_customer=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');return json(res,200,{ok:true});}
    if(route==='/api/orders'&&req.method==='POST'){
     const b=await body(req);if(!Array.isArray(b.items)||!b.items.length||b.items.length>50||!str(b.requestId,100)||!/^[a-zA-Z0-9-]+$/.test(b.requestId))return json(res,400,{error:'Choose 1–50 plans and supply an order request ID.'});
     if(b.serverName!==undefined&&(!str(b.serverName,80)||!b.serverName.trim()))return json(res,400,{error:'Server name must contain 1–80 characters.'});
     if(b.location!==undefined&&!['France','Germany','Singapore','United States'].includes(b.location))return json(res,400,{error:'Select an available location.'});
     const existing=orders.find(o=>o.userId===u.id&&o.requestId===b.requestId);if(existing)return json(res,200,{order:existing});
     if(!['card','easypaisa','jazzcash','upi'].includes(b.paymentMethod))return json(res,400,{error:'Choose Card, Easypaisa, JazzCash or UPI at checkout.'});
     const grouped=new Map();let units=0;
     for(const row of b.items){let id=typeof row==='string'?row:row?.planId;const quantity=typeof row==='string'?1:row?.quantity;if(['drift','current','storm'].includes(id))id='minecraft-intel-'+id;
      if(!str(id,120)||!Number.isInteger(quantity)||quantity<1||quantity>50)return json(res,400,{error:'Quantities must be whole numbers from 1 to 50.'});
      units+=quantity;if(units>50)return json(res,400,{error:'Maximum 50 hosting units per order.'});const [service,family]=id.split('-'),p=catalog.plans[service+'-'+family]?.find(p=>p.id===id);if(!p||!catalog.families[service]?.[family]?.available)return json(res,409,{error:'A plan is no longer available. Refresh your cart.'});grouped.set(id,(grouped.get(id)||0)+quantity);
     }
     const items=[];let subtotalCents=0,totalCents=0;
     for(const [id,quantity]of grouped){const [service,family]=id.split('-'),p=catalog.plans[service+'-'+family].find(p=>p.id===id),amounts=pricing.price(p);subtotalCents+=amounts.baseCents*quantity;totalCents+=amounts.unitCents*quantity;items.push({planId:p.id,service,family,name:p.name,quantity,basePrice:amounts.basePrice,discountPercent:amounts.discountPercent,price:amounts.unitPrice,lineTotal:amounts.unitCents*quantity/100,specs:p.specs,offer:p.offer});}
     const total=totalCents/100;
     if(b.expectedTotal!==undefined&&(!Number.isFinite(b.expectedTotal)||Math.round(b.expectedTotal*100)!==totalCents))return json(res,409,{error:'Prices or offers changed. Refresh checkout and review the new total before submitting.'});
     const o={id:crypto.randomUUID(),requestId:b.requestId,userId:u.id,userName:u.name,userEmail:u.email,items,total,subtotal:subtotalCents/100,savings:(subtotalCents-totalCents)/100,paymentMethod:b.paymentMethod,paymentStatus:'Not processed',paidAt:null,serverName:b.serverName?.trim()||u.name+' server',location:b.location||'France',currency:'USD',status:'Pending',note:'',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};
     orders.unshift(o);persist(paths.orders,orders);notify('Order',`New order request: ${u.email}`,`User: ${u.name} (${u.email})\nOrder: ${o.id}\nProducts: ${items.map(p=>p.service+' / '+p.name+' × '+p.quantity).join(', ')}\nMonthly total: USD ${total.toFixed(2)}\nSelected method: ${o.paymentMethod}\nStatus: Pending — no payment collected`,u.id);return json(res,201,{order:o});
    }
    return json(res,404,{error:'Not found.'});
   }
   const s=adminSession(req);if(!s)return json(res,401,{error:'Please sign in as an administrator.'});
   if(route==='/api/admin/session'&&req.method==='GET')return json(res,200,{email:credentials.email,csrf:s.csrf});
   if(route==='/api/admin/users'&&req.method==='GET')return json(res,200,{users:users.map(u=>({...safeUser(u),orderCount:orders.filter(o=>o.userId===u.id).length})),mailConfigured,notifications});
   if(route==='/api/admin/orders'&&req.method==='GET')return json(res,200,{orders,integration:ptero.state()});
   if(route==='/api/admin/panel'&&req.method==='GET')return json(res,200,{settings:ptero.settings()});
   if(req.headers['x-csrf-token']!==s.csrf)return json(res,403,{error:'Invalid security token. Refresh and sign in again.'});
   if(route==='/api/admin/panel'&&req.method==='PUT')return json(res,200,{settings:ptero.saveSettings(await body(req))});
   if(route==='/api/admin/panel/test'&&req.method==='POST')return json(res,200,await ptero.testConnection());
   if(route==='/api/admin/logout'&&req.method==='POST'){sessions.delete(s.id);res.setHeader('Set-Cookie','wavy_admin=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');return json(res,200,{ok:true});}
   if(route==='/api/admin/catalog'&&req.method==='PUT'){
    const c=await body(req);if(!c.home)c.home=structuredClone(catalog.home);for(const list of Object.values(c.plans||{}))if(Array.isArray(list))for(const p of list)if(p.offer===undefined)p.offer='';validate(c);if(c.version!==catalog.version)return json(res,409,{error:'Catalog changed in another tab. Reload before saving.'});
    c.version++;persist(paths.catalog,c);catalog=c;return json(res,200,catalog);
   }
   if(route==='/api/admin/orders'&&req.method==='PUT'){
    const b=await body(req),o=orders.find(o=>o.id===b.id);if(!o)return json(res,404,{error:'Order not found.'});
    if(!['Pending','Successful','Suspended'].includes(b.status)||!str(b.note||'',1000))return json(res,400,{error:'Invalid order status or note.'});
    if(b.updatedAt!==o.updatedAt)return json(res,409,{error:'Order changed in another tab. Refresh orders.'});
    if(deliveryLocks.has(o.id))return json(res,409,{error:'Delivery is already running. Refresh orders shortly.'});
    if(b.paymentStatus!==undefined&&!['Not processed','Unpaid','Paid'].includes(b.paymentStatus))return json(res,400,{error:'Invalid payment status.'});
    if(b.paymentStatus==='Paid'){const paid=b.paidAt||o.paidAt||new Date().toISOString();if(!Number.isFinite(Date.parse(paid))||Date.parse(paid)>Date.now()+60000)return json(res,400,{error:'Use a valid payment date, not in the future.'});o.paidAt=new Date(paid).toISOString();}else if(b.paymentStatus!==undefined)o.paidAt=null;
    if(b.paymentStatus!==undefined)o.paymentStatus=b.paymentStatus;
    const status=o.status;o.status=b.status;o.note=b.note||'';o.updatedAt=new Date(Math.max(Date.now(),Date.parse(o.updatedAt)+1)).toISOString();o.history=o.history||[];o.history.push({from:status,to:o.status,note:o.note,at:o.updatedAt,by:credentials.email});persist(paths.orders,orders);
    if(o.status==='Successful'&&o.paymentStatus==='Paid'){deliveryLocks.add(o.id);try{await ptero.deliver(o,users.find(u=>u.id===o.userId),saveOrders,saveUsers);}finally{deliveryLocks.delete(o.id);}}
    if(o.status==='Successful'&&o.paymentStatus!=='Paid'&&!o.delivery?.servers?.length){o.delivery={state:'Awaiting payment',message:'Your order is approved. Server delivery starts only after the administrator marks payment Paid.'};saveOrders();}
    return json(res,200,{order:o});
   }
   if(route==='/api/admin/password'&&req.method==='POST'){
    const b=await body(req);if(!str(b.current,256)||!equal(hash(b.current,credentials.salt),credentials.hash))return json(res,400,{error:'Current password is incorrect.'});
    if(!str(b.password,256)||b.password.length<12)return json(res,400,{error:'New password must contain at least 12 characters.'});
    credentials.salt=crypto.randomBytes(16).toString('hex');credentials.hash=hash(b.password,credentials.salt);persist(paths.admin,credentials);for(const id of sessions.keys())if(id!==s.id)sessions.delete(id);return json(res,200,{ok:true});
   }
   return json(res,404,{error:'Not found.'});
  }
  if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);return res.end();}
  const relative=decodeURIComponent(route).replace(/^\/+/, '')||'index.html';
  if(!/^(?:[A-Za-z0-9-]+\.html|catalog\.json|site-config\.js|index\.js|(?:assets|css|script)\/[A-Za-z0-9_./-]+)$/.test(relative)||relative.split('/').some(x=>x==='..'||x.startsWith('.'))){res.writeHead(404);return res.end('Not found');}
  if(relative==='catalog.json')return json(res,200,catalog);
  const f=path.join(ROOT,relative);if(!fs.existsSync(f)||!fs.statSync(f).isFile()){res.writeHead(404);return res.end('Not found');}
  const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.woff2':'font/woff2','.gif':'image/gif'};
  res.writeHead(200,{'Content-Type':types[path.extname(f)]||'application/octet-stream','Cache-Control':'no-cache'});if(req.method==='HEAD')return res.end();fs.createReadStream(f).pipe(res);
 }catch(e){json(res,400,{error:e instanceof SyntaxError?'Invalid JSON.':e.message});}
});
setInterval(()=>{for(const map of [sessions,customers,attempts])for(const [k,v]of map)if((v.expires||v.until)<Date.now())map.delete(k);},60000).unref();
server.listen(Number(process.env.PORT||3000),process.env.HOST||'127.0.0.1',()=>console.log('Wavy Cloud ready on port '+(process.env.PORT||3000)));
