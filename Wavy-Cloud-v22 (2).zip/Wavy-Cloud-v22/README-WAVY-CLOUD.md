# Wavy Cloud Hosting Site

A redesigned static landing page for **Wavy Cloud** — Minecraft and VPS hosting.

## Run locally

Open `index.html` directly, or serve the folder with any static server:

```bash
python3 -m http.server 8080
```

Then visit `http://localhost:8080`.

## Included interactions

- Responsive mobile navigation
- Dark/light theme toggle
- Hero “See how it works” modal
- Scroll reveal animation with a no-CDN fallback
- Monthly/yearly pricing toggle
- FAQ accordion
- Responsive Minecraft/VPS hosting sections and pricing cards

The supplied Wavy Cloud logo has been prepared as `assets/logo/wavy-cloud-mark.png`, `assets/logo/wavy-cloud-wordmark.png`, and `assets/logo/wavy-cloud-source.png`.

## Hosting detail pages

- `mincraft-hosting.html` — Minecraft hosting details
- `vps-hosting.html` — VPS hosting details

The homepage solution cards link directly to these pages.
